package model;

import java.io.Serializable;

public class PorderDetail  implements Serializable{
	private static final long serialVersionUID = 1L;
	private String porder_no;
	private String member_no;
	private String member_name;
	private String product_no;
	private String product_name;
	private int product_price;
	private int product_amount;
	private double member_discount;
	private int total;
	private String porder_time;
	
	
	public PorderDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PorderDetail(String porder_no, String member_no, String member_name, String product_no, String product_name,
			int product_price, int product_amount, double member_discount, int total, String porder_time) {
		super();
		this.porder_no = porder_no;
		this.member_no = member_no;
		this.member_name = member_name;
		this.product_no = product_no;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_amount = product_amount;
		this.member_discount = member_discount;
		this.total = total;
		this.porder_time = porder_time;
	}

	public String getPorder_no() {
		return porder_no;
	}

	public void setPorder_no(String porder_no) {
		this.porder_no = porder_no;
	}

	public String getMember_no() {
		return member_no;
	}

	public void setMember_no(String member_no) {
		this.member_no = member_no;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public String getProduct_no() {
		return product_no;
	}

	public void setProduct_no(String product_no) {
		this.product_no = product_no;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public int getProduct_amount() {
		return product_amount;
	}

	public void setProduct_amount(int product_amount) {
		this.product_amount = product_amount;
	}

	public double getMember_discount() {
		return member_discount;
	}

	public void setMember_discount(double member_discount) {
		this.member_discount = member_discount;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getPorder_time() {
		return porder_time;
	}

	public void setPorder_time(String porder_time) {
		this.porder_time = porder_time;
	}
	
	
	
}
