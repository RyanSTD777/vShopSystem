package model;

import java.io.Serializable;

public class Porder  implements Serializable{
	private static final long serialVersionUID = 1L;
	private int id;
	private String porderno;
	private String memberno;
	private String productno;
	private int amount;
	private String pordertime;
	
	
	public Porder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Porder(String porderno, String memberno, String productno, int amount) {
		super();
		this.porderno = porderno;
		this.memberno = memberno;
		this.productno = productno;
		this.amount = amount;
	}

	public Porder(String porderno, String memberno, String productno, int amount, String pordertime) {
		super();
		this.porderno = porderno;
		this.memberno = memberno;
		this.productno = productno;
		this.amount = amount;
		this.pordertime = pordertime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPorderno() {
		return porderno;
	}

	public void setPorderno(String porderno) {
		this.porderno = porderno;
	}

	public String getMemberno() {
		return memberno;
	}

	public void setMemberno(String memberno) {
		this.memberno = memberno;
	}

	public String getProductno() {
		return productno;
	}

	public void setProductno(String productno) {
		this.productno = productno;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	public String getPordertime() {
		return pordertime;
	}

	public void setPordertime(String pordertime) {
		this.pordertime = pordertime;
	}

	
	
}
