package model;

import java.io.Serializable;

public class VipLevel  implements Serializable{
	private static final long serialVersionUID = 1L;
	private int id;
	private String viplevelno;
	private String vname;
	private double discount;
	
	public VipLevel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VipLevel(String viplevelno, String vname, double discount) {
		super();
		this.viplevelno = viplevelno;
		this.vname = vname;
		this.discount = discount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getViplevelno() {
		return viplevelno;
	}

	public void setViplevelno(String viplevelno) {
		this.viplevelno = viplevelno;
	}

	public String getVname() {
		return vname;
	}

	public void setVname(String vname) {
		this.vname = vname;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	
	
}
