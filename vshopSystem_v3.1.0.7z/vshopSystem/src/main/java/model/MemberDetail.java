package model;

import java.io.Serializable;

public class MemberDetail  implements Serializable{
	private static final long serialVersionUID = 1L;
	private String memberno;
	private String mname;
	private String username;
	private String password;
	private String phone;
	private String address;
	private String viplevelno;
	private String vipname;
	private String vip_discount;
	
	public MemberDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDetail(String memberno, String mname, String username, String password, String phone, String address,
			String viplevelno, String vipname, String vip_discount) {
		super();
		this.memberno = memberno;
		this.mname = mname;
		this.username = username;
		this.password = password;
		this.phone = phone;
		this.address = address;
		this.viplevelno = viplevelno;
		this.vipname = vipname;
		this.vip_discount = vip_discount;
	}

	public String getMemberno() {
		return memberno;
	}

	public void setMemberno(String memberno) {
		this.memberno = memberno;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getViplevelno() {
		return viplevelno;
	}

	public void setViplevelno(String viplevelno) {
		this.viplevelno = viplevelno;
	}

	public String getVipname() {
		return vipname;
	}

	public void setVipname(String vipname) {
		this.vipname = vipname;
	}

	public String getVip_discount() {
		return vip_discount;
	}

	public void setVip_discount(String vip_discount) {
		this.vip_discount = vip_discount;
	}
	
	
	
}
