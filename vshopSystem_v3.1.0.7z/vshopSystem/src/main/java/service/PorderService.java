package service;

import java.util.List;

import model.Porder;

public interface PorderService {
	//create
	boolean addPorder(Porder porder);

	//read
	List<Porder> findAllPorder();
	List<Porder> findPorderByMemberno(String memberno);
	List<Porder> findByPorderno(String porderno);
	boolean checkPorderExistsByPordernoAndMemberno(String porderno, String memberno);
	boolean checkPorderExistsByPorderno(String porderno);

	//update
	boolean updatePorder(Porder porder);
	boolean updatePorderByPordernoAndProduct(Porder porder, String oldProductno);

	//delete
	boolean removePorder(Porder porder);
	boolean removePorderByProductnoAndPorderno(Porder porder);
		
}
