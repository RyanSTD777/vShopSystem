package service.impl;

import java.util.List;

import dao.impl.ProductDaoImpl;
import model.Product;
import service.ProductService;

public class ProductServiceImpl implements ProductService{

	public static void main(String[] args) {
//		System.out.println(new ProductServiceImpl().checkProductExistsByProductno("PD0001"));
	}
	
	ProductDaoImpl pdi = new ProductDaoImpl();
	
	@Override
	public void addProduct(Product product) {
		pdi.insertProduct(product);
		
	}

	@Override
	public List<Product> findAllProduct() {
		return pdi.selectAllProduct();
	}

	@Override
	public List<Product> findProductByProductno(String productno) {
		return pdi.selectProductByProductno(productno);
	}

	@Override
	public boolean checkProductExistsByProductno(String productno) {
		Product product = pdi.selectProductno(productno);
		return product!=null;
	}

	@Override
	public Product findByProductno(String productno) {
		return pdi.selectProductno(productno);
	}

	@Override
	public String findProductNameByno(String productno) {
		return pdi.getProductNameByno(productno);
	}

	@Override
	public String findProductNoByName(String productName) {
		return pdi.getProductNoByName(productName);
	}

	@Override
	public boolean updateProduct(Product product) {
		boolean exists = checkProductExistsByProductno(product.getProductno());
		if(exists) {
			pdi.updateProduct(product);
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean removeProduct(Product product) {
		boolean exists = checkProductExistsByProductno(product.getProductno());
		if(exists) {
			pdi.deleteProduct(product);
			return true;
		}else {
			return false;
		}
	}

	@Override
	public void updateProductQuantity(String productno, int newQuantity) {
        pdi.updateProductQuantity(productno, newQuantity);
    }
	
}