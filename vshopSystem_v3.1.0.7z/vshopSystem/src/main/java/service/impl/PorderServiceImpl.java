package service.impl;

import java.util.List;

import dao.impl.PorderDaoImpl;
import model.Porder;
import service.PorderService;

public class PorderServiceImpl implements PorderService{

	public static void main(String[] args) {
//		System.out.println(new ProderServiceImpl().checkPorderExistsByPorderno("P202508160418001"));
//		System.out.println(new ProderServiceImpl().checkPorderExistsByPordernoAndMemberno("P202508160418001", "M20250815001"));

	}
	
	PorderDaoImpl podi = new PorderDaoImpl();
	
	@Override
	public boolean addPorder(Porder porder) {
		try {
            podi.insertPorder(porder);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
	}

	@Override
	public List<Porder> findAllPorder() {
		return podi.selectAll();
	}

	@Override
	public List<Porder> findPorderByMemberno(String memberno) {
		return podi.selectByMemberno(memberno);
	}

	@Override
	public List<Porder> findByPorderno(String porderno) {
		// TODO Auto-generated method stub
		return podi.selectByPorderno(porderno);
	}

	@Override
	public boolean checkPorderExistsByPordernoAndMemberno(String porderno, String memberno) {
		List<Porder> result = podi.selectByPordernoAndMemberno(porderno, memberno);
		return !result.isEmpty();
	}

	@Override
	public boolean checkPorderExistsByPorderno(String porderno) {
		 List<Porder> list = podi.selectByPorderno(porderno);
		 return list != null && !list.isEmpty();
	}

	@Override
	public boolean updatePorder(Porder porder) {
		 List<Porder> list = podi.selectByPordernoAndProductno(porder.getPorderno(), porder.getProductno());
		    if(list != null && !list.isEmpty()) {
		        podi.updatePorder(porder);
		        return true;
		    }
		    return false;
	}

	@Override
	public boolean updatePorderByPordernoAndProduct(Porder porder, String oldProductno) {
	    List<Porder> list = podi.selectByPordernoAndProductno(porder.getPorderno(), oldProductno);
	    if (list == null || list.isEmpty()) {
	        return false;
	    }

	    List<Porder> duplicateCheck = podi.selectByPordernoAndProductno(porder.getPorderno(), porder.getProductno());
	    if (duplicateCheck != null && !duplicateCheck.isEmpty() && !porder.getProductno().equals(oldProductno)) {
	        System.out.println("已有該商品，無法修改。");
	        return false;
	    }

	    podi.updatePorderByPordernoAndProduct(porder, oldProductno);
	    return true;
	}


	@Override
	public boolean removePorder(Porder porder) {
		boolean exists = checkPorderExistsByPorderno(porder.getPorderno());
		if(exists) {
			podi.deletePorder(porder);
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean removePorderByProductnoAndPorderno(Porder porder) {
		List<Porder> list = podi.selectByPordernoAndProductno(porder.getPorderno(), porder.getProductno());
	    if(list != null && !list.isEmpty()) {
	        podi.deletePorderByProductnoAndPorderno(porder);
	        return true;
	    }
	    return false;
	}

}
