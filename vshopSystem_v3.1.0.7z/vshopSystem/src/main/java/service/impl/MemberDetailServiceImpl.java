package service.impl;

import java.util.List;

import dao.impl.MemberDetailDaoImpl;
import model.MemberDetail;
import service.MemberDetailService;

public class MemberDetailServiceImpl implements MemberDetailService{

	public static void main(String[] args) {
//		System.out.println(new MemberDetailServiceImpl().findByMemberno("M20250817001"));

	}
	
	private MemberDetailDaoImpl mddi = new MemberDetailDaoImpl();
	
	@Override
	public MemberDetail findByMemberno(String memberno) {
		return mddi.selectMemberno(memberno);
	}

	@Override
	public List<MemberDetail> findAll() {
		// TODO Auto-generated method stub
		return mddi.selectAll();
	}

}
