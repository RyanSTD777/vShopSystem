package service.impl;

import dao.impl.EmployDaoImpl;
import model.Employ;
import service.EmployService;

public class EmployServiceImpl implements EmployService{

	public static void main(String[] args) {
//		System.out.println(new EmployServiceImpl().existsByUsername("Admin"));
//		System.out.println(new EmployServiceImpl().isUsernameTaken("ryan"));
//		Employ employ = new Employ("E20250817001","員工01","Staff01","Staff01","part");
//		System.out.println(new EmployServiceImpl().regEmploy(employ));
//		System.out.println(new EmployServiceImpl().login("Admin", "Admin"));
//		System.out.println(new EmployServiceImpl().findByEmployno("E20250817001"));
//		System.out.println(new EmployServiceImpl().checkEmployExistsByEmployno("E20250817001"));
//		Employ employ = new EmployServiceImpl().findByEmployno("E20250817001");
//		employ.setPassword("Staff01");
//		System.out.println(new EmployServiceImpl().updateEmploy(employ));

	}
	
	private static EmployDaoImpl edi=new EmployDaoImpl();
	private static MemberServiceImpl msi = new MemberServiceImpl();

	@Override
	public boolean regEmploy(Employ employ) {
		boolean exists = isUsernameTaken(employ.getUsername());

        if (!exists) {
            edi.insertEmploy(employ);
            return true;
        } else {
            return false;
        }
	}

	@Override
	public boolean existsByUsername(String username) {
		Employ emp = edi.selectUsername(username);
		return emp != null;
	}

	@Override
	public boolean isUsernameTaken(String username) {
		boolean employExists = existsByUsername(username);
		boolean memberExists = msi.existsByUsername(username);

		return employExists || memberExists;
	}

	@Override
	public Employ login(String username, String password) {
		return edi.selectUsernameAndPassword(username, password);
	}

	@Override
	public Employ findByEmployno(String employno) {
		return edi.selectEmployno(employno);
	}

	@Override
	public boolean checkEmployExistsByEmployno(String employno) {
		Employ employ = edi.selectEmployno(employno);
		return employ!=null;
	}

	@Override
	public boolean updateEmploy(Employ employ) {
		boolean exists = checkEmployExistsByEmployno(employ.getEmployno());
	    if (exists) {
	        edi.updateEmploy(employ);
	        return true;
	    } else {
	        return false;
	    }
	}

}
