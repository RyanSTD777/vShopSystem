package service.impl;

import java.util.List;

import dao.impl.VipLevelDaoImpl;
import model.VipLevel;
import service.VipLevelService;

public class VipLevelServiceImpl implements VipLevelService{

	public static void main(String[] args) {
//		System.out.println(new VipLevelServiceImpl().findByVipLevelno("VIP000"));
//		System.out.println(new VipLevelServiceImpl().checkVipLevelExistsByVipLevelno("VIP000"));
//		VipLevel viplevel = new VipLevelServiceImpl().findByVipLevelno("VIP000");
//		viplevel.setDiscount(1);
//		System.out.println(new VipLevelServiceImpl().updateVipLevel(viplevel));
		

	}
	
	private VipLevelDaoImpl vdi = new VipLevelDaoImpl();

	@Override
	public VipLevel findByVipLevelno(String viplevelno) {
		return vdi.selectVipLevelno(viplevelno);
	}

	@Override
	public List<VipLevel> findAllVipLevels() {
		// TODO Auto-generated method stub
		return vdi.selectAllVipLevels();
	}

	@Override
	public boolean checkVipLevelExistsByVipLevelno(String vipleveno) {
		VipLevel viplevel = vdi.selectVipLevelno(vipleveno);
		return viplevel!=null;
	}

	@Override
	public boolean updateVipLevel(VipLevel viplevel) {
		boolean exists = checkVipLevelExistsByVipLevelno(viplevel.getViplevelno());
		if(exists)
		{
			vdi.updateVipLevel(viplevel);
			return true;
		}else {
			return false;
		}
	}
	
	
}
