package service.impl;

import java.util.List;

import dao.impl.PorderDetailDaoImpl;
import model.PorderDetail;
import service.PorderDetailService;

public class PorderDetailServiceImpl implements PorderDetailService{

	public static void main(String[] args) {
//		System.out.println(new PorderDetailServiceImpl().checkPorderDetailExistsByPorderno("P202508160418001"));
//		System.out.println(new PorderDetailServiceImpl().checkPorderDetailExistsByPordernoAndMemberno("P202508160418001", "M20250815001"));

	}
	
	PorderDetailDaoImpl poddi = new PorderDetailDaoImpl();

	@Override
	public List<PorderDetail> findAllPorderDetail() {
		return poddi.selectAll();
	}

	@Override
	public List<PorderDetail> findPorderDetailByMemberno(String member_no) {
		return poddi.selectByMemberno(member_no);
	}

	@Override
	public List<String> findPordernoByMemberno(String member_no) {
		return poddi.selectPordernoByMemberno(member_no);
	}

	@Override
	public List<PorderDetail> selectByOrderno(String order_no) {
		return poddi.selectByOrderno(order_no);
	}

	@Override
	public PorderDetail selectByOrderNoAndProduct(String order_no, String product_no) {
		return poddi.selectByOrdernoAndProductno(order_no, product_no);
	}

	@Override
	public boolean checkPorderDetailExistsByPordernoAndMemberno(String porder_no, String member_no) {
		List<PorderDetail> result = poddi.selectByPordernoAndMemberno(porder_no, member_no);
		return !result.isEmpty();
	}

	@Override
	public boolean checkPorderDetailExistsByPorderno(String porder_no) {
		PorderDetail porderdetail = poddi.selectPoderDetail(porder_no);
		return porderdetail!=null;
	}
	
	
}
