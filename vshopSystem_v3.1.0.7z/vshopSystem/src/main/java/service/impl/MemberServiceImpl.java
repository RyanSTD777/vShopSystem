package service.impl;

import dao.impl.MemberDaoImpl;
import model.Member;
import service.MemberService;

public class MemberServiceImpl implements MemberService{

	public static void main(String[] args) {
//		System.out.println(new MemberServiceImpl().existsByUsername("jhon"));
//		System.out.println(new MemberServiceImpl().isUsernameTaken("jhon"));
//		Member member= new Member("M20250817001","Jason","jason","1111","0911000111","台中","VIP002");
//		System.out.println(new MemberServiceImpl().regMember(member));
//		System.out.println(new MemberServiceImpl().login("jason", "1111"));
//		System.out.println(new MemberServiceImpl().findByMemberno("M20250817001"));
//		System.out.println(new MemberServiceImpl().checkMemberExistsByMemberno("M20250817001"));
//		Member member = new MemberServiceImpl().findByMemberno("M20250817001");
//		member.setPassword("4321");
//		member.setAddress("桃園");
//		member.setPhone("0988000888");
//		System.out.println(new MemberServiceImpl().updateMember(member));

	}
	
	private MemberDaoImpl mdi = new MemberDaoImpl();
	private static EmployServiceImpl esi=new EmployServiceImpl();

	@Override
	public boolean regMember(Member member) {
		boolean exists = isUsernameTaken(member.getUsername());

        if (!exists) {
            mdi.insertMember(member);
            return true;
        } else {
            return false;
        }
	}
	
	@Override
	public boolean existsByUsername(String username) {
		Member memb = mdi.selectUsername(username);
	    return memb != null;
	}

	@Override
	public boolean isUsernameTaken(String username) {
		boolean memberExists = existsByUsername(username);
		boolean employExists = esi.existsByUsername(username);

		return memberExists || employExists;
	}

	@Override
	public Member login(String username, String password) {
		return mdi.selectUsernameAndPassword(username, password);
	}

	@Override
	public Member findByMemberno(String memberno) {
		return mdi.selectMemberno(memberno);
	}

	@Override
	public boolean checkMemberExistsByMemberno(String memberno) {
		Member member = mdi.selectMemberno(memberno);
		return member!= null;
	}

	@Override
	public boolean updateMember(Member member) {
		boolean exists = checkMemberExistsByMemberno(member.getMemberno());
		if(exists)
		{
			mdi.updateMember(member);
			return true;
		} else {
	        return false;
	    }
	}

	@Override
	public boolean removeMember(String memberno) {
		try {
            mdi.deleteMember(memberno);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
	}

}
