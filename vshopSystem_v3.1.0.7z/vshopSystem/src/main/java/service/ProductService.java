package service;

import java.util.List;
import model.Product;

public interface ProductService {
	//create
	void addProduct(Product product);
	
	//read
	List<Product> findAllProduct();
	List<Product> findProductByProductno(String productno);
	boolean checkProductExistsByProductno(String productno);
	Product findByProductno(String productno);
	String findProductNameByno(String productno);
	String findProductNoByName(String productName);

	//update
	boolean updateProduct(Product product);
	void updateProductQuantity(String productno, int newQuantity);

	//delete
	boolean removeProduct(Product product);
	
	
}
