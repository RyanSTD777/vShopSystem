package service;

import java.util.List;

import model.MemberDetail;

public interface MemberDetailService {
	//create
	
	
	//read
	MemberDetail findByMemberno(String memberno);
	List<MemberDetail> findAll();
	
	//update
	
	
	//delete
	
	
	
}
