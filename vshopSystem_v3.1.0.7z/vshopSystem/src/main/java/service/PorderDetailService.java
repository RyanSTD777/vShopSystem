package service;

import java.util.List;

import model.PorderDetail;

public interface PorderDetailService {
	//create
	
	
	//read
	List<PorderDetail> findAllPorderDetail();
	List<PorderDetail> findPorderDetailByMemberno(String member_no);
	List<String> findPordernoByMemberno(String member_no);
	List<PorderDetail> selectByOrderno(String order_no);
	PorderDetail selectByOrderNoAndProduct(String order_no, String product_no);
	boolean checkPorderDetailExistsByPordernoAndMemberno(String porder_no, String member_no);
	boolean checkPorderDetailExistsByPorderno(String porder_no);
	
	//update
	
	
	//delete
	
	
}
