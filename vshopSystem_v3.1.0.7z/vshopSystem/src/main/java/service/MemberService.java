package service;

import model.Member;

public interface MemberService {
	//create
	boolean regMember(Member member);
			
	//read
	boolean existsByUsername(String username);
	boolean isUsernameTaken(String username);
	Member login(String username,String password);
	Member findByMemberno(String memberno);
	boolean checkMemberExistsByMemberno(String memberno);
	//update
	boolean updateMember(Member member);
	
	//delete
	boolean removeMember(String memberno);
	
}
