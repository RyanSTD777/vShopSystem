package service;

import java.util.List;

import model.VipLevel;

public interface VipLevelService {
	//create
	
	
	//read
	VipLevel findByVipLevelno(String viplevelno);
	boolean checkVipLevelExistsByVipLevelno(String vipleveno);
	List<VipLevel> findAllVipLevels();
	
	//update
	boolean updateVipLevel(VipLevel viplevel);
	
	//delete
	
	
}
