package service;

import model.Employ;

public interface EmployService {
	//create
	boolean regEmploy(Employ employ);
		
	//read
	boolean existsByUsername(String username);
	boolean isUsernameTaken(String username);
	Employ login(String username,String password);
	Employ findByEmployno(String employno);
	boolean checkEmployExistsByEmployno(String employno);
	
	
	//update
	boolean updateEmploy(Employ employ);
	
	//delete
	
	
	
}
