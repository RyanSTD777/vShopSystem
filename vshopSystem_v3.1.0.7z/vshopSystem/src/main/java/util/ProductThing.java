package util;

import java.awt.Font;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import model.Member;
import model.Porder;
import model.PorderDetail;
import model.Product;
import model.VipLevel;
import service.ProductService;
import service.impl.PorderDetailServiceImpl;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import service.impl.VipLevelServiceImpl;

public class ProductThing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void loadProducts(ProductService psi, DefaultTableModel productTableModel, List<Porder> cart) {
	    productTableModel.setRowCount(0);
	    List<Product> products = psi.findAllProduct();
	    for (Product p : products) {
	        // 計算購物車中已選的數量
	        int selectedAmount = 0;
	        if (cart != null) {
	            for (Porder po : cart) {
	                if (po.getProductno().equals(p.getProductno())) {
	                    selectedAmount += po.getAmount();
	                }
	            }
	        }
	        int availableQty = p.getQuantity() - selectedAmount;
	        if (availableQty < 0) availableQty = 0; // 避免庫存變成負數
	        productTableModel.addRow(new Object[] { p.getProductno(), p.getPname(), p.getPrice(), availableQty });
	    }
	}

	public static void showCartDialog(JFrame parentFrame, List<Porder> cart, ProductService psi) {
		if (cart.isEmpty()) {
			JOptionPane.showMessageDialog(parentFrame, "購物車目前是空的！", "提示", JOptionPane.WARNING_MESSAGE );
			return;
		}

		String[] columns = { "商品名稱", "數量", "單價", "小計" };
		DefaultTableModel cartModel = new DefaultTableModel(columns, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};

		int totalPrice = 0;
		for (Porder order : cart) {
			Product product = psi.findProductByProductno(order.getProductno()).get(0);
			int subTotal = product.getPrice() * order.getAmount();
			totalPrice += subTotal;
			cartModel.addRow(new Object[] { product.getPname(), order.getAmount(), product.getPrice(), subTotal });
		}

		JTable cartTable = new JTable(cartModel);
		JScrollPane scrollPane = new JScrollPane(cartTable);
		scrollPane.setPreferredSize(new java.awt.Dimension(400, 200));

		JButton btnRemove = new JButton("移除");
		JButton btnEditQty = new JButton("修改");

		JPanel panel = new JPanel(new java.awt.BorderLayout());
		panel.add(scrollPane, java.awt.BorderLayout.CENTER);

		JPanel btnPanel = new JPanel();
		btnPanel.add(btnEditQty);
		btnPanel.add(btnRemove);
		panel.add(btnPanel, java.awt.BorderLayout.SOUTH);

		JLabel totalLabel = new JLabel("總價： " + totalPrice + " 元");
		totalLabel.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		totalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		panel.add(totalLabel, java.awt.BorderLayout.NORTH);

		JDialog dialog = new JDialog(parentFrame, "購物車內容", true);
		dialog.getContentPane().add(panel);
		dialog.pack();
		dialog.setLocationRelativeTo(parentFrame);

		btnRemove.addActionListener(e -> {
			int selRow = cartTable.getSelectedRow();
			if (selRow == -1) {
				JOptionPane.showMessageDialog(dialog, "請先選擇要取消購買的商品!", "提示", JOptionPane.WARNING_MESSAGE );
				return;
			}
			cart.remove(selRow);
			cartModel.removeRow(selRow);
			dialog.dispose();
			showCartDialog(parentFrame, cart, psi);
		});

		btnEditQty.addActionListener(e -> {
			int selRow = cartTable.getSelectedRow();
			if (selRow == -1) {
				JOptionPane.showMessageDialog(dialog, "請先選擇要修改的商品!", "提示", JOptionPane.WARNING_MESSAGE);
				return;
			}
			Porder order = cart.get(selRow);
			Product product = psi.findProductByProductno(order.getProductno()).get(0);
			int stock = product.getQuantity();

			String input = JOptionPane.showInputDialog(
			        dialog,                       
			        "要為您修改為多少呢?（最高 " + stock + "）：", 
			        "請輸入數量",JOptionPane.QUESTION_MESSAGE,null,null,order.getAmount()
			).toString();

			if (input == null)
				return;
			int newQty;
			try {
				newQty = Integer.parseInt(input);
				if (newQty < 1 || newQty > stock) {
					JOptionPane.showMessageDialog(dialog, "數量需介於 1 ~ " + stock, "提示", JOptionPane.ERROR_MESSAGE);
					return;
				}
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(dialog, "請輸入數字喔!", "提示", JOptionPane.ERROR_MESSAGE);
				return;
			}

			order.setAmount(newQty);
			cartModel.setValueAt(newQty, selRow, 1);
			cartModel.setValueAt(product.getPrice() * newQty, selRow, 3);
			dialog.dispose();
			showCartDialog(parentFrame, cart, psi);
		});

		dialog.setVisible(true);
	}
	
    public static void displayCart(JTextArea textArea, List<Porder> cart, Member member, ProductService psi) {
        textArea.setText("");
        if (cart == null || cart.isEmpty()) {
            textArea.setText("購物車目前是空的！");
            return;
        }

        double discount = 1.0;
        VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
        if (vsi != null) {
            discount = vsi.getDiscount();
        }

        int totalOriginal = 0;
        int totalDiscount = 0;

        for (Porder order : cart) {
            List<Product> products = psi.findProductByProductno(order.getProductno());
            if (products == null || products.isEmpty()) continue;
            Product p = products.get(0);

            int subtotalOriginal = p.getPrice() * order.getAmount();
            int subtotalDiscount = (int)(subtotalOriginal * discount);
            totalOriginal += subtotalOriginal;
            totalDiscount += subtotalDiscount;

            textArea.append("商品名稱: " + p.getPname() + " ");
            textArea.append("數量: " + order.getAmount() + " ");
            textArea.append("原小計: " + subtotalOriginal + " 元 ");
            textArea.append("折扣後: " + subtotalDiscount + " 元\n\n");
        }

        textArea.append("================================\n");
        textArea.append("總價(原價): " + totalOriginal + " 元\n");
        textArea.append("總價(折扣後): " + totalDiscount + " 元\n");
    }
    
    public boolean checkout(Member member, List<Porder> cart) {
        try {
            for (Porder order : cart) {
            	new PorderServiceImpl().addPorder(order);
            	ProductServiceImpl prsi = new ProductServiceImpl();
                int currentStock = prsi.findProductByProductno(order.getProductno()).get(0).getQuantity();
                int newStock = currentStock - order.getAmount();
                if (newStock < 0) newStock = 0;

                prsi.updateProductQuantity(order.getProductno(), newStock);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static String showMyOrders(List<PorderDetail> orders) {
        StringBuilder sb = new StringBuilder();
        Map<String, List<PorderDetail>> orderMap = new LinkedHashMap<>();

        for (PorderDetail o : orders) {
            orderMap.computeIfAbsent(o.getPorder_no(), k -> new ArrayList<>()).add(o);
        }

        for (Map.Entry<String, List<PorderDetail>> entry : orderMap.entrySet()) {
            String porderNo = entry.getKey();
            List<PorderDetail> list = entry.getValue();

            String orderTime = list.get(0).getPorder_time();

            sb.append("下單時間: ").append(orderTime)
              .append("\n訂單號: ").append(porderNo)              
              .append("\n");

            int orderTotal = 0;
            for (PorderDetail d : list) {
                sb.append(d.getProduct_name())
                  .append(" x ").append(d.getProduct_amount())
                  .append("  ");
                orderTotal += d.getTotal();
            }

            sb.append("\n訂單總金額: ").append(orderTotal).append(" 元\n");
            sb.append("--------------------------------------\n");
        }

        if (sb.length() == 0) {
            sb.append("目前沒有任何訂單。");
        }

        return sb.toString();
    }

    

    public static void loadOrderNumbers(String memberno, JComboBox<String> comboBox) {
        comboBox.removeAllItems();
        comboBox.addItem("====請選擇訂單====");
        List<String> orderNos = new PorderDetailServiceImpl().findPordernoByMemberno(memberno);
        for (String orderNo : orderNos) {
            comboBox.addItem(orderNo);
        }
    }

    public static void loadOrderDetails(String orderno, DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        List<PorderDetail> details = new PorderDetailServiceImpl().selectByOrderno(orderno);
        for (PorderDetail d : details) {
            tableModel.addRow(new Object[]{
                d.getProduct_no(),
                d.getProduct_name(),
                d.getProduct_amount(),
                d.getProduct_price(),
                d.getTotal()
            });
        }
    }

    public static void updateOrder(JComboBox<String> comboBox, DefaultTableModel tableModel) {
        String orderNo = (String) comboBox.getSelectedItem();
        if (orderNo == null) {
            JOptionPane.showMessageDialog(null, "請先選擇訂單", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        PorderServiceImpl porderService = new PorderServiceImpl();

        boolean updated = false;

        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String productNo = (String) tableModel.getValueAt(i, 0);
            int newAmount = Integer.parseInt(tableModel.getValueAt(i, 2).toString());

            Porder porder = new Porder();
            porder.setPorderno(orderNo);
            porder.setProductno(productNo);
            porder.setAmount(newAmount);

            if (newAmount > 0) {
                porderService.updatePorder(porder);
                updated = true;
            } else {
                porderService.removePorderByProductnoAndPorderno(porder);
                updated = true;
            }
        }

        if (updated) {
            JOptionPane.showMessageDialog(null, "訂單已更新！", "提示", JOptionPane.INFORMATION_MESSAGE);
            loadOrderDetails(orderNo, tableModel);
        } else {
            JOptionPane.showMessageDialog(null, "沒有需要更新的項目", "提示", JOptionPane.WARNING_MESSAGE );
        }
    }

   
}
