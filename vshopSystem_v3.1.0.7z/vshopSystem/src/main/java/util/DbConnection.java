package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(DbConnection.getDb());
	}
	
	public static Connection getDb()
	{
		String url ="jdbc:mysql://localhost:3306/vshop_db";
		String user = "root";
		String password = "1234";
		Connection connection=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try {
				connection=DriverManager.getConnection(url, user, password);
			} catch (SQLException e) {
				System.out.println("no driver");
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
}
