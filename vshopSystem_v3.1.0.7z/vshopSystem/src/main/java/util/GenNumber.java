package util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static String generateMemberNo() {
		int count = 1;
		String timestamp = new SimpleDateFormat("yyyMMddHHmm").format(new Date());
		String serial = String.format("%03d", count);
		String memberno = "M" + timestamp + serial;
		
		if(count < 999) {
			count++;
		} else {
			count = 1;
		}
		return memberno;
	}
	
	public static String generateOrderNo() {
	    return "P" + System.currentTimeMillis(); // 簡單用時間戳作為訂單號
	}
}
