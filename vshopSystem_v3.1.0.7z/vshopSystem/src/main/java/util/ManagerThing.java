package util;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import model.Product;
import service.impl.ProductServiceImpl;

public class ManagerThing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void loadProductData(DefaultTableModel tableModel) {
		tableModel.setRowCount(0);
		List<Product> products = new ProductServiceImpl().findAllProduct();
		for (Product p : products) {
			tableModel.addRow(new Object[] { p.getProductno(), p.getPname(), p.getPrice(), p.getQuantity() });
		}
	}

	public static void updateProductData(DefaultTableModel tableModel) {
		ProductServiceImpl service = new ProductServiceImpl();
		boolean allSuccess = true;

		for (int i = 0; i < tableModel.getRowCount(); i++) {
			String productno = (String) tableModel.getValueAt(i, 0);
			String name = (String) tableModel.getValueAt(i, 1);

			int price;
			int quantity;
			try {
				price = Integer.parseInt(tableModel.getValueAt(i, 2).toString());
				quantity = Integer.parseInt(tableModel.getValueAt(i, 3).toString());
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "價格或庫存輸入錯誤，請檢查！", "提示", JOptionPane.ERROR_MESSAGE );
				allSuccess = false;
				continue;
			}

			Product p = service.findByProductno(productno);
			if (p != null) {
				if (!name.isEmpty())
				p.setPname(name);
				p.setPrice(price);
				p.setQuantity(quantity);

				boolean success = service.updateProduct(p);
				if (!success)
					allSuccess = false;
			}
		}

		if (allSuccess) {
			JOptionPane.showMessageDialog(null, "商品修改成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "部分商品修改失敗！", "提示", JOptionPane.ERROR_MESSAGE );
		}

		loadProductData(tableModel);
	}
}
