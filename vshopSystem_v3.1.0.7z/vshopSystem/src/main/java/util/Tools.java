package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import model.Porder;
import model.PorderDetail;
import model.VipLevel;
import model.Member;
import model.MemberDetail;
import service.ProductService;
import service.impl.PorderDetailServiceImpl;
import service.impl.VipLevelServiceImpl;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import dao.impl.MemberDetailDaoImpl;

public class Tools {
	
	public static void main(String[] args) {

	}
	
	public static void saveFile(Object object,String fileName)
	{
		try {
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(object);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static Object readFile(String fileName)
	{
		Object object = null;
		try {
			FileInputStream fis = new FileInputStream(fileName);
			ObjectInputStream ois = new ObjectInputStream(fis);
			object=ois.readObject();
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return object;
	}

	public static void exportOrderToExcel(Member member, List<Porder> cart, ProductService psi, String filePath) {
	    try (Workbook workbook = new XSSFWorkbook()) {
	        Sheet sheet = workbook.createSheet("Order");
	        VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());

	        Row header = sheet.createRow(0);
	        header.createCell(0).setCellValue("訂單號");
	        header.createCell(1).setCellValue("會員號");
	        header.createCell(2).setCellValue("會員姓名");
	        header.createCell(3).setCellValue("商品號");
	        header.createCell(4).setCellValue("商品名稱");
	        header.createCell(5).setCellValue("單價");
	        header.createCell(6).setCellValue("數量");
	        header.createCell(7).setCellValue("小計(去小數)");
	        header.createCell(8).setCellValue("下單時間");

	        int rowNum = 1;
	        double grandTotal = 0;

	        for (Porder p : cart) {
	            Row row = sheet.createRow(rowNum++);

	            double price = psi.findByProductno(p.getProductno()).getPrice();
	            double subtotal = price * p.getAmount();
	            int discountSubtotal = (int)(subtotal * vsi.getDiscount());

	            row.createCell(0).setCellValue(p.getPorderno());
	            row.createCell(1).setCellValue(member.getMemberno());
	            row.createCell(2).setCellValue(member.getMname());
	            row.createCell(3).setCellValue(p.getProductno());
	            row.createCell(4).setCellValue(psi.findByProductno(p.getProductno()).getPname());
	            row.createCell(5).setCellValue(price);
	            row.createCell(6).setCellValue(p.getAmount());
	            row.createCell(7).setCellValue((int) discountSubtotal);
	            row.createCell(8).setCellValue(p.getPordertime());
	           
	            grandTotal += discountSubtotal;
	        }

	        Row totalRow = sheet.createRow(rowNum + 1);
	        totalRow.createCell(6).setCellValue("折扣後總金額");
	        totalRow.createCell(7).setCellValue((int) grandTotal);

	        for (int i = 0; i <= 8; i++) {
	            sheet.autoSizeColumn(i);
	            int currentWidth = sheet.getColumnWidth(i);
	            sheet.setColumnWidth(i, currentWidth + 1024);
	        }

	        try (FileOutputStream fos = new FileOutputStream(filePath)) {
	            workbook.write(fos);
	        }

	        System.out.println("Excel 匯出成功: " + filePath);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	
	public static void exportAllMyOrdersToExcel(Member member, List<PorderDetail> orders, String filePath) {
	    try (Workbook workbook = new XSSFWorkbook()) {
	        Sheet sheet = workbook.createSheet("會員訂單");

	        Row header = sheet.createRow(0);
	        header.createCell(0).setCellValue("訂單號");
	        header.createCell(1).setCellValue("會員號");
	        header.createCell(2).setCellValue("會員姓名");
	        header.createCell(3).setCellValue("下單時間");
	        header.createCell(4).setCellValue("商品明細");
	        header.createCell(5).setCellValue("訂單總金額");

	        int rowNum = 1;

	        Map<String, List<PorderDetail>> orderMap = new LinkedHashMap<>();
	        for (PorderDetail o : orders) {
	            orderMap.computeIfAbsent(o.getPorder_no(), k -> new ArrayList<>()).add(o);
	        }

	        for (Map.Entry<String, List<PorderDetail>> entry : orderMap.entrySet()) {
	            String porderNo = entry.getKey();
	            List<PorderDetail> list = entry.getValue();

	            Row row = sheet.createRow(rowNum++);
	            row.createCell(0).setCellValue(porderNo);
	            row.createCell(1).setCellValue(member.getMemberno());
	            row.createCell(2).setCellValue(member.getMname());

	            String orderTime = list.get(0).getPorder_time();
	            row.createCell(3).setCellValue(orderTime);

	            StringBuilder productInfo = new StringBuilder();
	            int orderTotal = 0;
	            for (PorderDetail d : list) {
	                productInfo.append(d.getProduct_name())
	                           .append(" x").append(d.getProduct_amount())
	                           .append("  ");
	                orderTotal += d.getTotal();
	            }
	            row.createCell(4).setCellValue(productInfo.toString());
	            row.createCell(5).setCellValue(orderTotal);
	        }

	        for (int i = 0; i <= 5; i++) {
	            sheet.autoSizeColumn(i);
	            int currentWidth = sheet.getColumnWidth(i);
	            sheet.setColumnWidth(i, currentWidth + 1024);
	        }
	        sheet.setColumnWidth(4, 20 * 512); 

	        try (FileOutputStream fos = new FileOutputStream(filePath)) {
	            workbook.write(fos);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


	public static void exportAllOrdersToExcel(String filePath) {
	    PorderDetailServiceImpl service = new PorderDetailServiceImpl();
	    List<PorderDetail> details = service.findAllPorderDetail();
	    if (details == null || details.isEmpty()) {
	        throw new RuntimeException("沒有訂單資料");
	    }

	    Map<String, List<PorderDetail>> grouped = details.stream()
	        .collect(Collectors.groupingBy(PorderDetail::getPorder_no, LinkedHashMap::new, Collectors.toList()));

	    try (Workbook workbook = new XSSFWorkbook()) {
	        Sheet sheet = workbook.createSheet("訂單資料");
	        int rowIndex = 0;

	        // 標題列
	        Row header = sheet.createRow(rowIndex++);
	        header.createCell(0).setCellValue("訂單編號");
	        header.createCell(1).setCellValue("會員編號");
	        header.createCell(2).setCellValue("會員姓名");
	        header.createCell(3).setCellValue("下單時間");
	        header.createCell(4).setCellValue("商品明細");
	        header.createCell(5).setCellValue("小計");

	        for (Map.Entry<String, List<PorderDetail>> entry : grouped.entrySet()) {
	            String orderNo = entry.getKey();
	            List<PorderDetail> list = entry.getValue();
	            PorderDetail first = list.get(0);

	            StringBuilder productDetail = new StringBuilder();
	            double total = 0;

	            for (PorderDetail p : list) {
	                if (productDetail.length() > 0) productDetail.append("\n");
	                productDetail.append(p.getProduct_name()).append(" x ").append(p.getProduct_amount());
	                total += p.getTotal();
	            }

	            Row row = sheet.createRow(rowIndex++);
	            row.createCell(0).setCellValue(orderNo);
	            row.createCell(1).setCellValue(first.getMember_no());
	            row.createCell(2).setCellValue(first.getMember_name());
	            row.createCell(3).setCellValue(first.getPorder_time());
	            row.createCell(4).setCellValue(productDetail.toString());
	            row.createCell(5).setCellValue(total);
	        }

	        for (int i = 0; i <= 5; i++) {
	            sheet.autoSizeColumn(i);
	            int w = sheet.getColumnWidth(i);
	            sheet.setColumnWidth(i, Math.min(255*256, w + 1024));
	        }
	        sheet.setColumnWidth(4, 20 * 512);

	        try (FileOutputStream out = new FileOutputStream(filePath)) {
	            workbook.write(out);
	        }
	    } catch (Exception e) {
	        throw new RuntimeException("匯出失敗", e);
	    }
	}

	
	public static void exportAllMembersToExcel(String filePath) {
	    try {
	        MemberDetailDaoImpl service = new MemberDetailDaoImpl();
	        List<MemberDetail> members = service.selectAll();
	        if (members == null || members.isEmpty()) {
	            throw new RuntimeException("沒有會員資料可匯出");
	        }

	        Workbook workbook = new XSSFWorkbook();
	        Sheet sheet = workbook.createSheet("會員明細");

	        String[] headers = {"會員編號","姓名","帳號","電話","地址","會員等級","折扣"};
	        Row headerRow = sheet.createRow(0);
	        for (int i = 0; i < headers.length; i++) {
	            headerRow.createCell(i).setCellValue(headers[i]);
	        }

	        int rowNum = 1;
	        for (MemberDetail md : members) {
	            Row row = sheet.createRow(rowNum++);
	            row.createCell(0).setCellValue(md.getMemberno());
	            row.createCell(1).setCellValue(md.getMname());
	            row.createCell(2).setCellValue(md.getUsername());
	            row.createCell(3).setCellValue(md.getPhone());
	            row.createCell(4).setCellValue(md.getAddress());
	            row.createCell(5).setCellValue(md.getVipname());
	            row.createCell(6).setCellValue(md.getVip_discount());
	        }

	        for (int i = 0; i <= 6; i++) {
	            sheet.autoSizeColumn(i);
	            int w = sheet.getColumnWidth(i);
	            sheet.setColumnWidth(i, Math.min(255*256, w + 1024));
	        }

	        try (FileOutputStream out = new FileOutputStream(filePath)) {
	            workbook.write(out);
	        }
	        workbook.close();
	        System.out.println("全部會員明細匯出成功: " + filePath);
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("匯出全部會員明細失敗", e);
	    }
	}
}
