package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.MemberDetailDao;
import model.MemberDetail;
import util.DbConnection;

public class MemberDetailDaoImpl implements MemberDetailDao{

	public static void main(String[] args) {
		//System.out.println(new MemberDetailDaoImpl().selectMemberno("M20250815001"));
	}
	
	Connection conn = DbConnection.getDb();

	@Override
	public MemberDetail selectMemberno(String memberno) {
		MemberDetail memberdetail =null;
		String sql = "select * from memberdetail where memberno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, memberno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				memberdetail = new MemberDetail();
				memberdetail.setMemberno(rs.getString("memberno"));
				memberdetail.setMname(rs.getString("mname"));
				memberdetail.setUsername(rs.getString("username"));
				memberdetail.setPassword(rs.getString("password"));
				memberdetail.setPhone(rs.getString("phone"));
				memberdetail.setAddress(rs.getString("address"));
				memberdetail.setViplevelno(rs.getString("viplevelno"));
				memberdetail.setVipname(rs.getString("vipname"));
				memberdetail.setVip_discount(rs.getNString("vip_discount"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return memberdetail;
	}

	@Override
	public List<MemberDetail> selectAll() {
		List<MemberDetail> list = new ArrayList<>();
	    String sql = "select * from memberdetail";
	    try (PreparedStatement ps = conn.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            MemberDetail md = new MemberDetail();
	            md.setMemberno(rs.getString("memberno"));
	            md.setMname(rs.getString("mname"));
	            md.setUsername(rs.getString("username"));
	            md.setPassword(rs.getString("password"));
	            md.setPhone(rs.getString("phone"));
	            md.setAddress(rs.getString("address"));
	            md.setViplevelno(rs.getString("viplevelno"));
	            md.setVipname(rs.getString("vipname"));
	            md.setVip_discount(rs.getString("vip_discount"));
	            list.add(md);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	
	
}
