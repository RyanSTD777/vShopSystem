package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.PorderDetailDao;
import model.PorderDetail;
import util.DbConnection;

public class PorderDetailDaoImpl implements PorderDetailDao{

	public static void main(String[] args) {
//		System.out.println(new PorderDetailDaoImpl().selectPoderDetail("P202508160418001"));
//		System.out.println(new PorderDetailDaoImpl().selectAll());
//		System.out.println(new PorderDetailDaoImpl().selectByMemberno("M20250815001"));
//		System.out.println(new PorderDetailDaoImpl().selectByPordernoAndMemberno("P202508160418001", "M20250815001"));

	}
	
	Connection conn = DbConnection.getDb();

	@Override
	public List<PorderDetail> selectAll() {
		String sql = "select * from porderdetail";
		List<PorderDetail> porderdetailList = new ArrayList<PorderDetail>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				PorderDetail porderdetail = new PorderDetail();
				porderdetail.setPorder_no(rs.getString("porder_no"));
				porderdetail.setMember_no(rs.getString("member_no"));
				porderdetail.setMember_name(rs.getString("member_name"));
				porderdetail.setProduct_no(rs.getString("product_no"));
				porderdetail.setProduct_name(rs.getString("product_name"));
				porderdetail.setProduct_price(rs.getInt("product_price"));
				porderdetail.setProduct_amount(rs.getInt("product_amount"));
				porderdetail.setMember_discount(rs.getDouble("member_discount"));
				porderdetail.setTotal(rs.getInt("total"));
				porderdetail.setPorder_time(rs.getString("porder_time"));
				
				porderdetailList.add(porderdetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderdetailList;
	}

	@Override
	public List<PorderDetail> selectByMemberno(String member_no) {
		String sql = "select * from porderdetail where member_no=?";
		List<PorderDetail> porderdetailList = new ArrayList<PorderDetail>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, member_no);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				PorderDetail porderdetail = new PorderDetail();
				porderdetail.setPorder_no(rs.getString("porder_no"));
				porderdetail.setMember_no(rs.getString("member_no"));
				porderdetail.setMember_name(rs.getString("member_name"));
				porderdetail.setProduct_no(rs.getString("product_no"));
				porderdetail.setProduct_name(rs.getString("product_name"));
				porderdetail.setProduct_price(rs.getInt("product_price"));
				porderdetail.setProduct_amount(rs.getInt("product_amount"));
				porderdetail.setMember_discount(rs.getDouble("member_discount"));
				porderdetail.setTotal(rs.getInt("total"));
				porderdetail.setPorder_time(rs.getString("porder_time"));
				
				porderdetailList.add(porderdetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderdetailList;
	}
	


	@Override
	public List<String> selectPordernoByMemberno(String member_no) {
		List<String> porderno = new ArrayList<>();
	    String sql = "select distinct porder_no from porderdetail where member_no=?";
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, member_no);
	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	        	porderno.add(rs.getString("porder_no"));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return porderno;
	}

	@Override
	public List<PorderDetail> selectByPordernoAndMemberno(String porder_no, String member_no) {

		String sql = "select * from porderdetail where porder_no=? and member_no=?";
		List<PorderDetail> porderdetailList = new ArrayList<PorderDetail>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder_no);
			ps.setString(2, member_no);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				PorderDetail porderdetail = new PorderDetail();
				porderdetail.setPorder_no(rs.getString("porder_no"));
				porderdetail.setMember_no(rs.getString("member_no"));
				porderdetail.setMember_name(rs.getString("member_name"));
				porderdetail.setProduct_no(rs.getString("product_no"));
				porderdetail.setProduct_name(rs.getString("product_name"));
				porderdetail.setProduct_price(rs.getInt("product_price"));
				porderdetail.setProduct_amount(rs.getInt("product_amount"));
				porderdetail.setMember_discount(rs.getDouble("member_discount"));
				porderdetail.setTotal(rs.getInt("total"));
				porderdetail.setPorder_time(rs.getString("porder_time"));
				
				porderdetailList.add(porderdetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderdetailList;
	}

	@Override
	public List<PorderDetail> selectByOrderno(String order_no) {
		List<PorderDetail> list = new ArrayList<>();
	    String sql = "select * from porderdetail where porder_no=?";
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, order_no);
	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            PorderDetail d = new PorderDetail();
	            d.setProduct_no(rs.getString("product_no"));
	            d.setProduct_name(rs.getString("product_name"));
	            d.setProduct_amount(rs.getInt("product_amount"));
	            d.setProduct_price(rs.getInt("product_price"));
	            d.setTotal(rs.getInt("total"));
	            d.setPorder_time(rs.getString("porder_time"));
	            list.add(d);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return list;
	}

	@Override
	public PorderDetail selectByOrdernoAndProductno(String order_no, String product_no) {
		String sql = "select * from porderdetail where porder_no=? and product_no=?";
	    PorderDetail detail = null;
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setString(1, order_no);
	        ps.setString(2, product_no);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            detail = new PorderDetail();
	            detail.setPorder_no(rs.getString("porder_no"));
	            detail.setProduct_no(rs.getString("product_no"));
	            detail.setProduct_name(rs.getString("product_name"));
	            detail.setProduct_amount(rs.getInt("product_amount"));
	            detail.setProduct_price(rs.getInt("product_price"));
	            detail.setPorder_time(rs.getString("porder_time"));
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return detail;
	}
	
	@Override
	public PorderDetail selectPoderDetail(String porder_no) {
		PorderDetail porderdetail =null;
		String sql = "select * from porderdetail where porder_no=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder_no);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				porderdetail = new PorderDetail();
				porderdetail.setPorder_no(rs.getString("porder_no"));
				porderdetail.setMember_no(rs.getString("member_no"));
				porderdetail.setMember_name(rs.getString("member_name"));
				porderdetail.setProduct_no(rs.getString("product_no"));;
				porderdetail.setProduct_name(rs.getString("product_name"));
				porderdetail.setProduct_price(rs.getInt("product_price"));
				porderdetail.setProduct_amount(rs.getInt("product_amount"));
				porderdetail.setMember_discount(rs.getDouble("member_discount"));
				porderdetail.setTotal(rs.getInt("total"));
				porderdetail.setPorder_time(rs.getString("porder_time"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porderdetail;
	}

}
