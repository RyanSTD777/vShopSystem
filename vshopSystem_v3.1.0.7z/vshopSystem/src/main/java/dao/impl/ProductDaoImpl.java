package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ProductDao;
import model.Product;
import util.DbConnection;

public class ProductDaoImpl implements ProductDao{

	public static void main(String[] args) {
//		Product pd = new Product("PD0002","胡蘿蔔",10,20);
//		new ProductDaoImpl().insertProduct(pd);
//		System.out.println(new ProductDaoImpl().selectAllProduct());
//		System.out.println(new ProductDaoImpl().selectProductno("PD0001"));
//		Product pd = new ProductDaoImpl().selectProductno("PD0001");
//		pd.setPrice(26);
//		pd.setQuantity(20);
//		new ProductDaoImpl().updateProduct(pd);

	}
	
	Connection conn = DbConnection.getDb();
	
	@Override
	public void insertProduct(Product product) {
		String sql ="insert into product(id, productno, pname, price, quantity) values(?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, product.getId());
			ps.setString(2, product.getProductno());
			ps.setString(3, product.getPname());
			ps.setInt(4, product.getPrice());
			ps.setInt(5, product.getQuantity());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Product> selectAllProduct() {
		String sql="select * from product";
		List<Product> productList = new ArrayList<Product>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductno(rs.getString("productno"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getInt("price"));
				product.setQuantity(rs.getInt("quantity"));
				
				productList.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return productList;
	}

	@Override
	public List<Product> selectProductByProductno(String productno) {
		String sql="select * from product where productno=?";
		List<Product> productList = new ArrayList<Product>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, productno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductno(rs.getString("productno"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getInt("price"));
				product.setQuantity(rs.getInt("quantity"));
				
				productList.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return productList;
	}

	@Override
	public Product selectProductno(String productno) {
		Product product = null;
		String sql="select * from product where productno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, productno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductno(rs.getString("productno"));
				product.setPname(rs.getString("pname"));
				product.setPrice(rs.getInt("price"));
				product.setQuantity(rs.getInt("quantity"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return product;
	}

	@Override
	public String getProductNameByno(String productno) {
		String pname = "產品名";
        String sql = "select pname from product where productno = ?";
        try (Connection conn = DbConnection.getDb();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, productno);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pname = rs.getString("pname");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pname;
	}

	@Override
	public String getProductNoByName(String pname) {
		 String productno = null;
	        String sql = "select productno from product where pname = ?";
	        try (Connection conn = DbConnection.getDb();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, pname);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                productno = rs.getString("productno");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return productno;
	}

	@Override
	public void updateProduct(Product product) {
	    String sql = "update product set pname=?, price=?, quantity=? where productno=?";
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, product.getPname());
	        ps.setInt(2, product.getPrice());
	        ps.setInt(3, product.getQuantity());
	        ps.setString(4, product.getProductno());

	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void updateProductQuantity(String productno, int newQuantity) {
		String sql = "update product set quantity=? where productno=?";
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setInt(1, newQuantity);
	        ps.setString(2, productno);
	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void deleteProduct(Product product) {
		String sql = "delete from product where productno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, product.getProductno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
