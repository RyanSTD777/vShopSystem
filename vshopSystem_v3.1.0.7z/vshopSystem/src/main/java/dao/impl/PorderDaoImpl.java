package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.PorderDao;
import model.Porder;
import util.DbConnection;

public class PorderDaoImpl implements PorderDao{

	public static void main(String[] args) {
//		Porder porder = new Porder("P202508160418001","M20250815001","PD0001",2);
//		new PorderDaoImpl().insertPorder(porder);
//		System.out.println(new PorderDaoImpl().selectPorderno("P202508160418001"));
//		Porder porder = new PorderDaoImpl().selectPorderno("P1755774716251");
//		porder.setProductno("PD0003");
//		porder.setAmount(2);
//		new PorderDaoImpl().updatePorder(porder);
//		System.out.println(new PorderDaoImpl().selectByPordernoAndMemberno("P202508160418001", "M20250815001"));

	}
	
	Connection conn = DbConnection.getDb();

	@Override
	public void insertPorder(Porder porder) {
		String sql = "insert into porder(porderno, memberno, productno, amount, pordertime) "
				+ "values(?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder.getPorderno());
			ps.setString(2, porder.getMemberno());
			ps.setString(3, porder.getProductno());
			ps.setInt(4, porder.getAmount());
			ps.setString(5, porder.getPordertime());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Porder> selectAll() {
		String sql = "select * from porder";
		List<Porder> porderList = new ArrayList<Porder>(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderno(rs.getString("porderno"));
				porder.setMemberno(rs.getString("memberno"));
				porder.setProductno(rs.getString("productno"));
				porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
				
				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderList;
	}

	@Override
	public List<Porder> selectByMemberno(String memberno) {
		String sql = "select * from porder where memberno=?";
		List<Porder> porderList = new ArrayList<Porder>(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, memberno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderno(rs.getString("porderno"));
				porder.setMemberno(rs.getString("memberno"));
				porder.setProductno(rs.getString("productno"));
				porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
				
				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderList;
	}

	@Override
	public List<Porder> selectByPordernoAndMemberno(String porderno, String memberno) {
		String sql = "select * from porder where porderno=? and memberno=?";
		List<Porder> porderList = new ArrayList<Porder>(); 
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porderno);
			ps.setString(2, memberno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderno(rs.getString("porderno"));
				porder.setMemberno(rs.getString("memberno"));
				porder.setProductno(rs.getString("productno"));
				porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
				
				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderList;
	}

	@Override
	public Porder selectPorderno(String porderno) {
		Porder porder = null;
		String sql = "select * from porder where porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porderno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderno(rs.getString("porderno"));
				porder.setMemberno(rs.getString("memberno"));
				porder.setProductno(rs.getString("productno"));
				porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porder;
	}

	@Override
	public List<Porder> selectByPorderno(String porderno) {
		String sql = "select * from porder where porderno=?";
	    List<Porder> list = new ArrayList<>();
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, porderno);
	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            Porder porder = new Porder();
	            porder.setId(rs.getInt("id"));
	            porder.setPorderno(rs.getString("porderno"));
	            porder.setMemberno(rs.getString("memberno"));
	            porder.setProductno(rs.getString("productno"));
	            porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
	            list.add(porder);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	
	public List<Porder> selectByPordernoAndProductno(String porderno, String productno) {
	    String sql = "select * from porder where porderno=? and productno=?";
	    List<Porder> list = new ArrayList<>();
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, porderno);
	        ps.setString(2, productno);
	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            Porder porder = new Porder();
	            porder.setId(rs.getInt("id"));
	            porder.setPorderno(rs.getString("porderno"));
	            porder.setMemberno(rs.getString("memberno"));
	            porder.setProductno(rs.getString("productno"));
	            porder.setAmount(rs.getInt("amount"));
				porder.setPordertime(rs.getString("pordertime"));
	            list.add(porder);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	}
	
	@Override
	public void updatePorder(Porder porder) {
		String sql="update porder set amount=? where productno=? and porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, porder.getAmount());
			ps.setString(2, porder.getProductno());
			ps.setString(3, porder.getPorderno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	


	@Override
	public void updatePorderByPordernoAndProduct(Porder porder, String oldProductno) {
	    String sql = "update porder set productno=?, amount=? " +
	                 "where porderno=? and productno=?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setString(1, porder.getProductno());
	        ps.setInt(2, porder.getAmount());
	        ps.setString(3, porder.getPorderno());
	        ps.setString(4, oldProductno);
	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	@Override
	public void deletePorder(Porder porder) {
		String sql="delete from porder where porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder.getPorderno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void deletePorderByProductnoAndPorderno(Porder porder) {
		String sql="delete from porder where productno=? and porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder.getProductno());
			ps.setString(2, porder.getPorderno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
