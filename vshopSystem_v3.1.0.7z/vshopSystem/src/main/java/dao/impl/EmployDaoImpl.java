package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.EmployDao;
import model.Employ;
import util.DbConnection;

public class EmployDaoImpl implements EmployDao{

	public static void main(String[] args) {
		
//		 Employ employ= new Employ("E20250815001","後台管理員","Admin","Admin","all");
//		 EmployDaoImpl().inserEmploy(employ);
//		 EmployDaoImpl().selectUsernameAndPassword("Admin","Admin"));
//		 
//		
//		 System.out.println(new EmployDaoImpl().selectEmployno("E20250815001"));
//		 Employ ed =new EmployDaoImpl().selectEmployno("E20250815001")
//		 ed.setPassword("Admin")
//		 new EmployDaoImpl().updateEmploy(ed);
		 
	}
	
	Connection conn=DbConnection.getDb();
	
	@Override
	public void insertEmploy(Employ employ) {
		String sql="insert into employ(employno, ename, username, password, role) values(?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, employ.getEmployno());
			ps.setString(2, employ.getEname());
			ps.setString(3, employ.getUsername());
			ps.setString(4, employ.getPassword());
			ps.setString(5, employ.getRole());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Employ selectEmployno(String employno) {
		Employ employ = null;
		String sql="select * from employ where employno=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, employno);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				employ = new Employ();
				employ.setId(rs.getInt("id"));
				employ.setEmployno(rs.getString("employno"));
				employ.setEname(rs.getString("ename"));
				employ.setUsername(rs.getString("username"));
				employ.setPassword(rs.getString("password"));
				employ.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employ;
	}

	@Override
	public Employ selectUsername(String username) {
		Employ employ = null;
		String sql="select * from employ where username=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				employ = new Employ();
				employ.setId(rs.getInt("id"));
				employ.setEmployno(rs.getString("employno"));
				employ.setEname(rs.getString("ename"));
				employ.setUsername(rs.getString("username"));
				employ.setPassword(rs.getString("password"));
				employ.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employ;
	}

	@Override
	public Employ selectUsernameAndPassword(String username, String password) {
		Employ employ = null;
		String sql="select * from employ where username=? and password=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				employ = new Employ();
				employ.setId(rs.getInt("id"));
				employ.setEmployno(rs.getString("employno"));
				employ.setEname(rs.getString("ename"));
				employ.setUsername(rs.getString("username"));
				employ.setPassword(rs.getString("password"));
				employ.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employ;
	}

	@Override
	public void updateEmploy(Employ employ) {
		String sql="update employ set password=? where employno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, employ.getPassword());
			ps.setString(2, employ.getEmployno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
