package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.MemberDao;
import model.Member;
import util.DbConnection;

public class MemberDaoImpl implements MemberDao {

	public static void main(String[] args) {

//		Member member= new Member("M20250815001","Jhon","jhon","1234","0911222333","台北","VIP000");
//		new MemberDaoImpl().insertMember(member);		 
//		System.out.println(new MemberDaoImpl().selectUsernameAndPassword("jhon","1234"));
		Member md = new MemberDaoImpl().selectMemberno("M20250815001");
		md.setPassword("111");
		md.setAddress("台中");
		md.setPhone("0911333222");
		new MemberDaoImpl().updateMember(md);

	}

	Connection conn = DbConnection.getDb();

	@Override
	public void insertMember(Member member) {
		String sql = "insert into member(memberno,mname,username,password,phone,address,viplevelno) "
				+ "values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, member.getMemberno());
			ps.setString(2, member.getMname());
			ps.setString(3, member.getUsername());
			ps.setString(4, member.getPassword());
			ps.setString(5, member.getPhone());
			ps.setString(6, member.getAddress());
			ps.setString(7, member.getViplevelno());

			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public Member selectMemberno(String memberno) {
		Member member = null;
		String sql = "select * from member where memberno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, memberno);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				member = new Member();
				member.setId(rs.getInt("id"));
				member.setMemberno(rs.getString("memberno"));
				member.setMname(rs.getString("mname"));
				member.setUsername(rs.getString("username"));
				member.setPassword(rs.getString("password"));
				member.setPhone(rs.getString("phone"));
				member.setAddress(rs.getString("address"));
				member.setViplevelno(rs.getString("viplevelno"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}

	@Override
	public Member selectUsername(String username) {
		Member member = null;
		String sql = "select * from member where username=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				member = new Member();
				member.setId(rs.getInt("id"));
				member.setMemberno(rs.getString("memberno"));
				member.setMname(rs.getString("mname"));
				member.setUsername(rs.getString("username"));
				member.setPassword(rs.getString("password"));
				member.setPhone(rs.getString("phone"));
				member.setAddress(rs.getString("address"));
				member.setViplevelno(rs.getString("viplevelno"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}

	@Override
	public Member selectUsernameAndPassword(String username, String password) {
		Member member = null;
		String sql = "select * from member where username=? and password=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				member = new Member();
				member.setId(rs.getInt("id"));
				member.setMemberno(rs.getString("memberno"));
				member.setMname(rs.getString("mname"));
				member.setUsername(rs.getString("username"));
				member.setPassword(rs.getString("password"));
				member.setPhone(rs.getString("phone"));
				member.setAddress(rs.getString("address"));
				member.setViplevelno(rs.getString("viplevelno"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return member;
	}

	@Override
	public void updateMember(Member member) {
		String sql = "update member set mname=?, password=?, phone=?, address=?, viplevelno=? where memberno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, member.getMname());
			ps.setString(2, member.getPassword());
			ps.setString(3, member.getPhone());
			ps.setString(4, member.getAddress());
			ps.setString(5, member.getViplevelno());
			ps.setString(6, member.getMemberno());

			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteMember(String memberno) {
		String sql = "delete from member where memberno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, memberno);
			
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
