package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.VipLevelDao;
import model.VipLevel;
import util.DbConnection;

public class VipLevelDaoImpl implements VipLevelDao{

	public static void main(String[] args) {
//		System.out.println(new VipLevelDaoImpl().selectVipLevelno("VIP000"));
//		VipLevel vd = new VipLevelDaoImpl().selectVipLevelno("VIP000");
//		vd.setDiscount(1);
//		new VipLevelDaoImpl().updateVipLevel(vd);

	}
	
	Connection conn = DbConnection.getDb();
	
	@Override
	public VipLevel selectVipLevelno(String viplevelno) {
		VipLevel viplevel = null;
		String sql = "select * from viplevel where viplevelno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, viplevelno);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				viplevel = new VipLevel();
				viplevel.setId(rs.getInt("id"));
				viplevel.setViplevelno(rs.getString("viplevelno"));
				viplevel.setVname(rs.getString("vname"));
				viplevel.setDiscount(rs.getDouble("discount"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return viplevel;
	}

	@Override
	public List<VipLevel> selectAllVipLevels() {
        List<VipLevel> list = new ArrayList<>();
        String sql = "select * from viplevel";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                VipLevel v = new VipLevel();
                v.setId(rs.getInt("id"));
                v.setViplevelno(rs.getString("viplevelno"));
                v.setVname(rs.getString("vname"));
                v.setDiscount(rs.getDouble("discount"));
                list.add(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


	@Override
	public void updateVipLevel(VipLevel viplevel) {
		String sql = "update viplevel set discount=? where viplevelno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setDouble(1, viplevel.getDiscount());
			ps.setString(2, viplevel.getViplevelno());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
