package dao;

import java.util.List;

import model.Product;

public interface ProductDao {
	//create
	void insertProduct(Product product);
	
	//read
	List<Product> selectAllProduct();
	List<Product> selectProductByProductno(String productno);
	Product selectProductno(String productno);
	String getProductNameByno(String productno);
	String getProductNoByName(String productName);
	
	//update
	void updateProduct(Product product);
	void updateProductQuantity(String productno, int newQuantity);
	
	//delete
	void deleteProduct(Product product);
	
	
}
