package dao;

import java.util.List;

import model.PorderDetail;

public interface PorderDetailDao {
	//create
	
	
	//read
	List<PorderDetail> selectAll();
	List<PorderDetail> selectByMemberno(String member_no);
	List<String> selectPordernoByMemberno(String member_no);
	List<PorderDetail> selectByOrderno(String order_no);
	List<PorderDetail> selectByPordernoAndMemberno(String porder_no, String member_no);
	PorderDetail selectByOrdernoAndProductno(String order_no, String product_no);
	PorderDetail selectPoderDetail(String porder_no);
	
	//update
	
	
	//delete
	
	
}
