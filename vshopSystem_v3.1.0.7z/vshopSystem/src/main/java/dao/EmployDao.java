package dao;

import model.Employ;

public interface EmployDao {
	//create
	void insertEmploy(Employ employ);
	
	//read
    Employ selectEmployno(String employno);
    Employ selectUsername(String username);
    Employ selectUsernameAndPassword(String username,String password);
    
	
	//update
    void updateEmploy(Employ employ);
	
	//delete
	
	
	
}
