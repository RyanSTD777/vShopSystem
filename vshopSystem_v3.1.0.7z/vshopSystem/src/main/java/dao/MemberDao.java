package dao;

import model.Member;

public interface MemberDao {
	//create
	void insertMember(Member member);
	
	//read
	Member selectMemberno(String memberno);
	Member selectUsername(String username);
	Member selectUsernameAndPassword(String username,String password);
	
	//update
	void updateMember(Member member);
	
	//delete	
	void deleteMember(String memberno);
	
}
