package dao;

import java.util.List;

import model.VipLevel;

public interface VipLevelDao {
	//create
	
	
	//read
	VipLevel selectVipLevelno(String viplevelno);
	List<VipLevel> selectAllVipLevels();
	
	
	//update
	void updateVipLevel(VipLevel viplevel);
	
	//delete
	
	
}
