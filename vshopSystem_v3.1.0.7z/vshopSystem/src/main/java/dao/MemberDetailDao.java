package dao;

import java.util.List;

import model.MemberDetail;

public interface MemberDetailDao {
	//create
	
	
	//read
	MemberDetail selectMemberno(String memberno);
	List<MemberDetail> selectAll();
	
	//upload
	
	
	//delete
	
	
	
}
