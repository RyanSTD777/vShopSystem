package dao;

import java.util.List;

import model.Porder;

public interface PorderDao {
	//create
	void insertPorder(Porder porder);
	
	//read
	List<Porder> selectAll();
	List<Porder> selectByMemberno(String memberno);
	List<Porder> selectByPorderno(String porderno);
	List<Porder> selectByPordernoAndMemberno(String porderno, String memberno);
	Porder selectPorderno(String porderno);
	List<Porder> selectByPordernoAndProductno(String porderno, String productno);
	
	
	//update
	void updatePorder(Porder porder);
	void updatePorderByPordernoAndProduct(Porder porder, String oldProductno);
	
	//delete
	void deletePorder(Porder porder);
	void deletePorderByProductnoAndPorderno(Porder porder);
	
}
