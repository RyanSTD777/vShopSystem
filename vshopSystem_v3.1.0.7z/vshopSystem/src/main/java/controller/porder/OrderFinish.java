package controller.porder;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Login;
import model.Member;
import model.Porder;
import model.VipLevel;
import service.ProductService;
import service.impl.ProductServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.ProductThing;
import util.Tools;

import javax.swing.JButton;
import javax.swing.JScrollPane;

public class OrderFinish extends JFrame {

	private static final long serialVersionUID = 1L;
	private Member member;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	    EventQueue.invokeLater(() -> {
	        try {
	            Member testMember = new Member();
	            testMember.setMname("會員");
	            List<Porder> testCart = List.of();
	            ProductService psi = new ProductServiceImpl();

	            OrderFinish frame = new OrderFinish(testMember, testCart, psi);
	            frame.setVisible(true);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    });
	}

	/**
	 * Create the frame.
	 */
	public OrderFinish(Member member, List<Porder> cart, ProductService psi) {
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    setUndecorated(true);
	    setSize(490, 390);
	    setLocationRelativeTo(null);

	    JPanel contentPane = new JPanel();
	    contentPane.setBackground(new Color(244, 244, 244));
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    contentPane.setLayout(null);
	    setContentPane(contentPane);
	    
	    JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 470, 100);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 412, 19);
		panel.add(welcomeMsg);

		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
				}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(428, 10, 32, 19);
		panel.add(logout);

		this.member = (Member) Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show = "<" + vsi.getVname() + "> " + member.getMname() + " 您好";
		welcomeMsg.setText(show);

		JLabel titleLabel = new JLabel("訂單完成");
		titleLabel.setBounds(0, 35, 460, 40);
		panel.add(titleLabel);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 28));
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    
	    JPanel panel1 = new JPanel();
	    panel1.setBounds(10, 113, 470, 267);
	    contentPane.add(panel1);
	    panel1.setLayout(null);
	    
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(10, 10, 310, 247);
	    panel1.add(scrollPane);

	    JTextArea textArea = new JTextArea();
	    scrollPane.setViewportView(textArea);
	    textArea.setFont(new Font("微軟正黑體", Font.BOLD, 12));
	    textArea.setEditable(false);
	    
	    JButton btnBack = new JButton("回首頁");
	    btnBack.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		PorderHome porderhome = new PorderHome();
        		porderhome.setVisible(true);
        		dispose();
	    	}
	    });
	    btnBack.setForeground(new Color(255, 255, 255));
	    btnBack.setBackground(new Color(0, 128, 192));
	    btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
	    btnBack.setBounds(347, 169, 99, 41);
	    panel1.add(btnBack);
	    
	    JButton btnExcel = new JButton("<html>匯出<br>Excel</html>");
	    btnExcel.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		String path = "我的購物訂單.xlsx";
	            Tools.exportOrderToExcel(member, cart, psi, path);
	            JOptionPane.showMessageDialog(OrderFinish.this, "我的購物訂單已匯出！\n檔案名稱: " + path, "提示", JOptionPane.INFORMATION_MESSAGE);
	    	}
	    });
	    btnExcel.setForeground(Color.WHITE);
	    btnExcel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
	    btnExcel.setBackground(new Color(255, 128, 64));
	    btnExcel.setBounds(347, 39, 99, 82);
	    panel1.add(btnExcel);

	    if (cart != null && member != null && psi != null) {
	        ProductThing.displayCart(textArea, cart, member, psi);
	        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	        String orderTime = LocalDateTime.now().format(dtf);

	        textArea.append("\n================================\n");
	        textArea.append("下單時間: " + orderTime);
	    }
	}
}
