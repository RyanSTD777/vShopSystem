package controller.porder;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Login;
import controller.member.MyAcc;
import controller.member.MyOrder;
import model.Member;
import model.VipLevel;
import service.impl.VipLevelServiceImpl;
import util.Tools;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.JButton;

public class PorderHome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PorderHome frame = new PorderHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PorderHome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 244, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 471, 100);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel titleLabel = new JLabel("俗俗賣蔬菜行");
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
		titleLabel.setBounds(10, 33, 451, 57);
		panel.add(titleLabel);
		
		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login,"是否登出系統?","登出提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
					return;
					}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(429, 10, 32, 19);
		panel.add(logout);
		
		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 413, 19);
		panel.add(welcomeMsg);
		
		Member member = (Member)Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show="<"+vsi.getVname()+"> "+member.getMname()+" 您好";
		welcomeMsg.setText(show);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 111, 471, 271);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton marketButton = new JButton("市集");
		marketButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Market market = new Market();
				market.setVisible(true);
				dispose();
			}
		});
		marketButton.setForeground(new Color(255, 255, 255));
		marketButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		marketButton.setBackground(new Color(0, 128, 255));
		marketButton.setBounds(152, 10, 134, 46);
		marketButton.setFocusPainted(false);
		panel_1.add(marketButton);
		
		JButton exitButton = new JButton("離開系統");
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PorderHome porderhome = new PorderHome();
				if (JOptionPane.showConfirmDialog(porderhome,"是否離開系統?","關閉提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					System.exit(0);
					}
			}
		});
		exitButton.setForeground(Color.WHITE);
		exitButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		exitButton.setFocusPainted(false);
		exitButton.setBackground(new Color(255, 0, 0));
		exitButton.setBounds(152, 215, 134, 46);
		panel_1.add(exitButton);
		
		JButton myorderButton = new JButton("我的訂單");
		myorderButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MyOrder myorder = new MyOrder();
				myorder.setVisible(true);
				dispose();
			}
		});
		myorderButton.setForeground(Color.WHITE);
		myorderButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		myorderButton.setFocusPainted(false);
		myorderButton.setBackground(new Color(0, 128, 0));
		myorderButton.setBounds(152, 77, 134, 46);
		panel_1.add(myorderButton);
		
		JButton myaccButton = new JButton("我的帳號");
		myaccButton.setForeground(Color.WHITE);
		myaccButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MyAcc myacc = new MyAcc();
				myacc.setVisible(true);
				dispose();
			}
		});
		myaccButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		myaccButton.setFocusPainted(false);
		myaccButton.setBackground(new Color(255, 128, 0));
		myaccButton.setBounds(152, 146, 134, 46);
		panel_1.add(myaccButton);

	}
}
