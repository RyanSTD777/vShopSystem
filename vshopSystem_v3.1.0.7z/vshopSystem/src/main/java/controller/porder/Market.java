package controller.porder;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.Login;
import model.Member;
import model.Porder;
import model.Product;
import model.VipLevel;
import service.ProductService;
import service.impl.ProductServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.ProductThing;
import util.Tools;

public class Market extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPanel panel_1;
    private JButton btnViewCart;
    private JTable productTable;
    private DefaultTableModel productTableModel;
    private final ProductService psi = new ProductServiceImpl();
    private List<Porder> cart;
    private Member member;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Market frame = new Market();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Market() {
        this.member = (Member) Tools.readFile("data/member.txt");
        this.cart = new ArrayList<>();
        initialize();
    }

    public Market(Member member, List<Porder> cart) {
        this.member = member;
        this.cart = cart;
        initialize();
    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(490, 390);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(244, 244, 244));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(244, 244, 244));
        panel.setBounds(10, 10, 471, 100);
        contentPane.add(panel);
        panel.setLayout(null);
        
        JLabel welcomeMsg = new JLabel("");
        welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
        welcomeMsg.setForeground(new Color(0, 0, 0));
        welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        welcomeMsg.setBounds(10, 10, 413, 19);
        panel.add(welcomeMsg);

        JLabel titleLabel = new JLabel("俗俗賣蔬菜行");
        titleLabel.setForeground(new Color(0, 64, 128));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
        titleLabel.setBounds(10, 33, 451, 57);
        panel.add(titleLabel);

        JLabel logout = new JLabel("登出");
        logout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Login login = new Login();
                if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    new File("data/member.txt").delete();
                    new File("data/porder.txt").delete();
                    login.setVisible(true);
                    dispose();
                }
            }
        });
        logout.setForeground(new Color(0, 0, 255));
        logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        logout.setBounds(429, 10, 32, 19);
        panel.add(logout);

        VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
        String show = "<" + vsi.getVname() + "> " + member.getMname() + " 您好";
        welcomeMsg.setText(show);

        panel_1 = new JPanel();
        panel_1.setBackground(new Color(244, 244, 244));
        panel_1.setBounds(10, 127, 471, 255);
        contentPane.add(panel_1);
        panel_1.setLayout(null);
        
        initProductTable();
    }

    private void initProductTable() {
        String[] columns = { "商品編號", "商品名稱", "價格", "庫存" };
        productTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(productTableModel);
        productTable.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        productTable.setRowHeight(28);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setBounds(0, 0, 471, 170);
        panel_1.add(scrollPane);
        
        btnViewCart = new JButton("查看購物車");
        btnViewCart.setForeground(new Color(255, 255, 255));
        btnViewCart.setBackground(new Color(255, 128, 64));
        btnViewCart.setFocusPainted(false);
        btnViewCart.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnViewCart.setBounds(157, 212, 157, 25);
        panel_1.add(btnViewCart);
        
        JButton btnBack = new JButton("返回首頁");
        btnBack.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		PorderHome porderhome = new PorderHome();
        		porderhome.setVisible(true);
        		dispose();
        	}
        });
        btnBack.setForeground(Color.WHITE);
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setBounds(10, 212, 119, 25);
        panel_1.add(btnBack);
        
        JButton btnOK = new JButton("我選好了");
        btnOK.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (cart == null || cart.isEmpty()) {
                    JOptionPane.showMessageDialog(Market.this, "購物車為空，無法結帳！", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                OrderConfirm confirm = new OrderConfirm(cart, member);
                confirm.setVisible(true);
                dispose();
            }
        });
        btnOK.setForeground(Color.WHITE);
        btnOK.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnOK.setFocusPainted(false);
        btnOK.setBackground(new Color(0, 128, 192));
        btnOK.setBounds(342, 212, 119, 25);
        panel_1.add(btnOK);
        
        JLabel lblNewLabel = new JLabel("溫馨提示: 點兩下商品可輸入數量");
        lblNewLabel.setForeground(new Color(128, 0, 128));
        lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblNewLabel.setBounds(10, 177, 451, 25);
        panel_1.add(lblNewLabel);

        btnViewCart.addActionListener(e -> ProductThing.showCartDialog(Market.this, cart, psi));

        ProductThing.loadProducts(psi, productTableModel, cart);

        productTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = productTable.getSelectedRow();
                    if (row != -1) {
                        String productno = productTableModel.getValueAt(row, 0).toString();
                        String pname = productTableModel.getValueAt(row, 1).toString();
                        int price = Integer.parseInt(productTableModel.getValueAt(row, 2).toString());

                        List<Product> productList = psi.findProductByProductno(productno);
                        if (productList == null || productList.isEmpty()) {
                            JOptionPane.showMessageDialog(Market.this, "查無此商品資料！", "提示", JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                        Product product = productList.get(0);
                        int stock = product.getQuantity();

                        int existingAmount = 0;
                        for (Porder p : cart) {
                            if (p.getProductno().equals(productno)) {
                                existingAmount += p.getAmount();
                            }
                        }

                        int maxAvailable = stock - existingAmount;
                        if (maxAvailable <= 0) {
                            JOptionPane.showMessageDialog(Market.this, "很抱歉 " + pname + " 賣完了！", "提示", JOptionPane.WARNING_MESSAGE);
                            return;
                        }

                        String amountStr = JOptionPane.showInputDialog(
                                Market.this,
                                "您需要多少\"" + pname + "\"?（剩餘：" + maxAvailable + "）","輸入數量",JOptionPane.QUESTION_MESSAGE);

                        if (amountStr == null) return;
                        int amount;
                        try {
                            amount = Integer.parseInt(amountStr);
                            if (amount < 1 || amount > maxAvailable) {
                                JOptionPane.showMessageDialog(Market.this, "麻煩您輸入 1 ~ " + maxAvailable + " 之間的數量喔!", "提示", JOptionPane.ERROR_MESSAGE );
                                return;
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(Market.this, "麻煩您輸入數字喔!", "提示", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        boolean found = false;
                        for (Porder p : cart) {
                            if (p.getProductno().equals(productno)) {
                                p.setAmount(p.getAmount() + amount);
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            Porder order = new Porder();
                            order.setProductno(productno);
                            order.setAmount(amount);
                            cart.add(order);
                        }

                        int updatedStock = stock - (existingAmount + amount);
                        productTableModel.setValueAt(updatedStock, row, 3);

                        JOptionPane.showMessageDialog(Market.this, pname + " 已加入購物車", "提示",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });
    }
}
