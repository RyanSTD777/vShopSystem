package controller.porder;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Login;
import model.Member;
import model.Porder;
import model.VipLevel;
import service.PorderService;
import service.ProductService;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.GenNumber;
import util.ProductThing;
import util.Tools;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class OrderConfirm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextArea textArea;
	private List<Porder> cart;
	private Member member;
	private final ProductService psi = new ProductServiceImpl();
	private final PorderService posi = new PorderServiceImpl();

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Member testMember = new Member();
				testMember.setMname("會員");

				List<Porder> testCart = List.of();

				OrderConfirm frame = new OrderConfirm(testCart, testMember);
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Create the frame
	 */
	public OrderConfirm(List<Porder> cart, Member member) {
		this.cart = cart;

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 244, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 470, 100);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 408, 19);
		panel.add(welcomeMsg);

		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
				}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(428, 10, 32, 19);
		panel.add(logout);

		this.member = (Member) Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show = "<" + vsi.getVname() + "> " + member.getMname() + " 您好";
		welcomeMsg.setText(show);

		JLabel titleLabel = new JLabel("訂單確認");
		titleLabel.setBounds(0, 35, 460, 40);
		panel.add(titleLabel);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 28));
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 117, 470, 203);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 8, 450, 185);
		panel_1.add(scrollPane);

		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
		textArea.setEditable(false);
		
		ProductThing.displayCart(textArea, cart, member, psi);

		JButton btnCheckout = new JButton("結帳");
		btnCheckout.setBounds(295, 329, 124, 31);
		contentPane.add(btnCheckout);
		btnCheckout.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		btnCheckout.setBackground(new Color(0, 128, 192));
		btnCheckout.setForeground(Color.WHITE);

		btnCheckout.addActionListener(e -> {
		    if (cart == null || cart.isEmpty()) {
		        JOptionPane.showMessageDialog(this, "購物車為空，無法結帳！", "提示", JOptionPane.WARNING_MESSAGE );
		    } else {
		        boolean allSuccess = true;

		        String orderNo = GenNumber.generateOrderNo();

		        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

		        for (Porder order : cart) {
		            order.setPorderno(orderNo);
		            order.setMemberno(member.getMemberno());
		            order.setPordertime(now);;

		            boolean success = posi.addPorder(order);
		            if (!success) {
		                allSuccess = false;
		                break;
		            }

		            int currentQty = psi.findProductByProductno(order.getProductno())
		                                .get(0).getQuantity();
		            int newQty = currentQty - order.getAmount();
		            if (newQty < 0) newQty = 0;
		            psi.updateProductQuantity(order.getProductno(), newQty);
		        }

		        if (!allSuccess) {
		            JOptionPane.showMessageDialog(this, "結帳失敗！請稍後再試。", "提示", JOptionPane.ERROR_MESSAGE );
		            return;
		        }

		        JOptionPane.showMessageDialog(this, "結帳成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
		        OrderFinish finishFrame = new OrderFinish(member, cart, psi);
		        finishFrame.setVisible(true);
		        dispose();
		    }
		});
		
		JButton btnCheckout_1 = new JButton("返回選購商品");
		btnCheckout_1.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        Market market = new Market(member, cart);
		        market.setVisible(true);
		        dispose();
		    }
		});
		btnCheckout_1.setForeground(Color.WHITE);
		btnCheckout_1.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		btnCheckout_1.setBackground(new Color(0, 128, 0));
		btnCheckout_1.setBounds(69, 330, 157, 31);
		contentPane.add(btnCheckout_1);
	}
}
