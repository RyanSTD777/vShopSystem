package controller.employ;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import controller.Login;
import model.Employ;
import model.Porder;
import model.Product;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import util.Tools;
import javax.swing.JTextField;

public class OrderManager extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    PorderServiceImpl psi = new PorderServiceImpl();
    ProductServiceImpl prodService = new ProductServiceImpl();
    private JTextField orderNo;
    private JTable orderShow;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                OrderManager frame = new OrderManager();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public OrderManager() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(490, 390);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(244, 244, 244));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        List<Product> allProducts = prodService.findAllProduct();

        JPanel panel = new JPanel();
        panel.setBackground(new Color(244, 244, 244));
        panel.setBounds(10, 10, 471, 100);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("訂單管理");
        titleLabel.setForeground(new Color(0, 64, 128));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
        titleLabel.setBounds(10, 33, 451, 57);
        panel.add(titleLabel);

        JLabel logout = new JLabel("登出");
        logout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Login login = new Login();
                if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
                    new File("data/employ.txt").delete();
                    login.setVisible(true);
                    dispose();
                    return;
                }
            }
        });
        logout.setForeground(new Color(0, 0, 255));
        logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        logout.setBounds(429, 10, 32, 19);
        panel.add(logout);

        JLabel welcomeMsg = new JLabel("");
        welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
        welcomeMsg.setForeground(new Color(0, 0, 0));
        welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        welcomeMsg.setBounds(10, 10, 413, 19);
        panel.add(welcomeMsg);

        Employ employ = (Employ) Tools.readFile("data/employ.txt");
        String show = employ.getEname() + " 您好";
        welcomeMsg.setText(show);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(244, 244, 244));
        panel_1.setBounds(10, 111, 471, 271);
        contentPane.add(panel_1);
        panel_1.setLayout(null);

        JLabel lblorderNo = new JLabel("訂單編號:");
        lblorderNo.setHorizontalAlignment(SwingConstants.RIGHT);
        lblorderNo.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblorderNo.setBounds(10, 10, 89, 25);
        panel_1.add(lblorderNo);

        orderNo = new JTextField();
        orderNo.setToolTipText("請輸入訂單編號");
        orderNo.setColumns(10);
        orderNo.setBounds(109, 10, 192, 28);
        panel_1.add(orderNo);

        orderShow = new JTable();
        JScrollPane scrollPane = new JScrollPane(orderShow);
        scrollPane.setBounds(23, 56, 276, 151);
        panel_1.add(scrollPane);

        
        /*按扭區*/
        JButton btnExcel = new JButton("Excel匯出全部訂單");
        btnExcel.setBounds(238, 231, 192, 30);
        btnExcel.setFocusPainted(false);
        btnExcel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Tools.exportAllOrdersToExcel("全部訂單.xlsx");
                JOptionPane.showMessageDialog(null, "匯出完成：全部訂單.xlsx", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        btnExcel.setBackground(new Color(255, 128, 64));
        btnExcel.setForeground(Color.WHITE);
        btnExcel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        panel_1.add(btnExcel);

        JButton btnBack = new JButton("返回首頁");
        btnBack.setBounds(59, 231, 120, 30);
        btnBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ManagerHome managerhome = new ManagerHome();
                managerhome.setVisible(true);
                dispose();
            }
        });
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setFocusPainted(false);
        btnBack.setForeground(Color.WHITE);
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        panel_1.add(btnBack);
        
        JButton btnSearch = new JButton("查詢");
        btnSearch.setBackground(new Color(64, 0, 128));
        btnSearch.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String pordernoText = orderNo.getText().trim();
                if (pordernoText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "請輸入訂單編號！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                List<Porder> orderList = psi.findByPorderno(pordernoText);
                if (orderList == null || orderList.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "查無訂單資料！", "提示", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String[] columns = {"商品名稱", "數量"};
                Object[][] data = new Object[orderList.size()][2];
                List<String> originalProductNoList = new ArrayList<>();

                for (int i = 0; i < orderList.size(); i++) {
                    Porder p = orderList.get(i);
                    String pname = allProducts.stream()
                            .filter(prod -> prod.getProductno().equals(p.getProductno()))
                            .map(Product::getPname)
                            .findFirst()
                            .orElse("未知商品");
                    data[i][0] = pname;
                    data[i][1] = p.getAmount();
                    originalProductNoList.add(p.getProductno());
                }

                DefaultTableModel model = new DefaultTableModel(data, columns) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return true;
                    }
                };
                orderShow.setModel(model);
                orderShow.putClientProperty("originalProductNoList", originalProductNoList);

                TableColumn productColumn = orderShow.getColumnModel().getColumn(0);
                JComboBox<String> comboBox = new JComboBox<>(allProducts.stream().map(Product::getPname).toArray(String[]::new));
                productColumn.setCellEditor(new javax.swing.DefaultCellEditor(comboBox));
            }
        });
        btnSearch.setFocusPainted(false);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnSearch.setBounds(316, 10, 145, 27);
        panel_1.add(btnSearch);

        JButton btnDelOrderNo = new JButton("刪除訂單");
        btnDelOrderNo.setForeground(Color.WHITE);
        btnDelOrderNo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String pordernoText = orderNo.getText().trim();
                if (pordernoText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "請輸入訂單編號！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                int confirm = JOptionPane.showConfirmDialog(null,
                        "確定要刪除訂單編號 " + pordernoText + " 的所有訂單嗎？",
                        "刪除確認", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    Porder porder = new Porder();
                    porder.setPorderno(pordernoText);
                    boolean success = psi.removePorder(porder);
                    if (success) {
                        JOptionPane.showMessageDialog(null, "訂單刪除成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "找不到該訂單或刪除失敗！", "提示", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        btnDelOrderNo.setFocusPainted(false);
        btnDelOrderNo.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnDelOrderNo.setBackground(new Color(255, 0, 0));
        btnDelOrderNo.setBounds(316, 58, 145, 27);
        panel_1.add(btnDelOrderNo);

        JButton btnDelOrderPD = new JButton("刪除訂單項目");
        btnDelOrderPD.setForeground(Color.WHITE);
        btnDelOrderPD.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = orderShow.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "請先選擇要刪除的訂單項目！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                String pordernoText = orderNo.getText().trim();
                if (pordernoText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "請輸入訂單編號！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                List<String> originalProductNoList = (List<String>) orderShow.getClientProperty("originalProductNoList");
                String oldProductno = originalProductNoList.get(selectedRow);

                int confirm = JOptionPane.showConfirmDialog(null,
                        "確定要刪除該訂單項目？",
                        "刪除確認", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    Porder porder = new Porder();
                    porder.setPorderno(pordernoText);
                    porder.setProductno(oldProductno);

                    boolean success = psi.removePorderByProductnoAndPorderno(porder);
                    if (success) {
                        JOptionPane.showMessageDialog(null, "訂單項目刪除成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                        ((DefaultTableModel) orderShow.getModel()).removeRow(selectedRow);
                        originalProductNoList.remove(selectedRow);
                        orderShow.putClientProperty("originalProductNoList", originalProductNoList);
                    } else {
                        JOptionPane.showMessageDialog(null, "刪除失敗，請檢查！", "提示", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        btnDelOrderPD.setFocusPainted(false);
        btnDelOrderPD.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnDelOrderPD.setBackground(Color.RED);
        btnDelOrderPD.setBounds(316, 100, 145, 27);
        panel_1.add(btnDelOrderPD);
        


        JButton btnEditOrder = new JButton("修改訂單");
        btnEditOrder.setForeground(Color.WHITE);
        btnEditOrder.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            	if (orderShow.isEditing()) 
            	    orderShow.getCellEditor().stopCellEditing();
                String pordernoText = orderNo.getText().trim();
                if (pordernoText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "請輸入訂單編號！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                int rowCount = orderShow.getRowCount();
                List<String> originalProductNoList = (List<String>) orderShow.getClientProperty("originalProductNoList");
                Set<String> selectedNames = new HashSet<>();

                for (int i = 0; i < rowCount; i++) {
                    String pname = orderShow.getValueAt(i, 0).toString();
                    if (selectedNames.contains(pname)) {
                        JOptionPane.showMessageDialog(null, "商品名稱不能重複：" + pname, "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    selectedNames.add(pname);
                }

                boolean allSuccess = true;
                for (int i = 0; i < rowCount; i++) {
                    String pname = orderShow.getValueAt(i, 0).toString();
                    int amount;
                    try {
                        amount = Integer.parseInt(orderShow.getValueAt(i, 1).toString());
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "數量格式錯誤！", "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    String oldProductno = originalProductNoList.get(i);

                    if (amount <= 0) {
                        Porder delOrder = new Porder();
                        delOrder.setPorderno(pordernoText);
                        delOrder.setProductno(oldProductno);
                        boolean delSuccess = psi.removePorderByProductnoAndPorderno(delOrder);
                        if (delSuccess) {
                            ((DefaultTableModel) orderShow.getModel()).removeRow(i);
                            originalProductNoList.remove(i);
                            i--;
                        } else {
                            allSuccess = false;
                        }
                        continue;
                    }

                    Product product = allProducts.stream().filter(p -> p.getPname().equals(pname)).findFirst().orElse(null);
                    if (product == null) {
                        JOptionPane.showMessageDialog(null, "找不到商品：" + pname, "提示", JOptionPane.ERROR_MESSAGE);
                        allSuccess = false;
                        continue;
                    }

                    Porder porder = new Porder();
                    porder.setPorderno(pordernoText);
                    porder.setProductno(product.getProductno());
                    porder.setAmount(amount);

                    boolean success = psi.updatePorderByPordernoAndProduct(porder, oldProductno);
                    if (!success) allSuccess = false;
                }

                if (allSuccess) {
                    JOptionPane.showMessageDialog(null, "訂單修改完成！", "提示", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "部分資料修改失敗，請檢查！", "提示", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnEditOrder.setFocusPainted(false);
        btnEditOrder.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnEditOrder.setBackground(new Color(0, 128, 192));
        btnEditOrder.setBounds(316, 144, 145, 63);
        panel_1.add(btnEditOrder);
        
    }
}
