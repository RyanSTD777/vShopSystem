package controller.employ;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.Login;
import model.Employ;
import model.Member;
import model.MemberDetail;
import model.VipLevel;
import service.impl.MemberDetailServiceImpl;
import service.impl.MemberServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.Tools;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class MemberManager extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable memberShow;
    private JTextField memberNo;
    private List<VipLevel> allVipLevels;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MemberManager frame = new MemberManager();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MemberManager() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(490, 390);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(244, 244, 244));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        allVipLevels = new VipLevelServiceImpl().findAllVipLevels();
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(244, 244, 244));
        panel.setBounds(10, 10, 471, 100);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("會員管理");
        titleLabel.setForeground(new Color(0, 64, 128));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
        titleLabel.setBounds(10, 33, 451, 57);
        panel.add(titleLabel);

        JLabel logout = new JLabel("登出");
        logout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Login login = new Login();
                if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
                    new File("data/employ.txt").delete();
                    login.setVisible(true);
                    dispose();
                    return;
                }
            }
        });
        logout.setForeground(new Color(0, 0, 255));
        logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        logout.setBounds(429, 10, 32, 19);
        panel.add(logout);

        JLabel welcomeMsg = new JLabel("");
        welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
        welcomeMsg.setForeground(new Color(0, 0, 0));
        welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        welcomeMsg.setBounds(10, 10, 413, 19);
        panel.add(welcomeMsg);

        Employ employ = (Employ) Tools.readFile("data/employ.txt");
        String show = employ.getEname() + " 您好";
        welcomeMsg.setText(show);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(244, 244, 244));
        panel_1.setBounds(10, 111, 471, 269);
        contentPane.add(panel_1);
        panel_1.setLayout(null);

        JLabel lblNewLabel = new JLabel("會員編號:");
        lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblNewLabel.setBounds(10, 10, 109, 25);
        panel_1.add(lblNewLabel);

        memberNo = new JTextField();
        memberNo.setToolTipText("請輸入會員編號");
        memberNo.setBounds(129, 10, 201, 25);
        panel_1.add(memberNo);
        memberNo.setColumns(10);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(28, 51, 310, 163);
        panel_1.add(scrollPane);

        memberShow = new JTable();
        memberShow.setRowHeight(30);
        scrollPane.setViewportView(memberShow);
        
        JButton btnSearch = new JButton("查詢");
        btnSearch.setBackground(new Color(64, 0, 128));
        btnSearch.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            String no = memberNo.getText().trim();
            if (no.isEmpty()) {
                JOptionPane.showMessageDialog(null, "請輸入會員編號", "提示", JOptionPane.WARNING_MESSAGE );
                return;
            }
            MemberDetail md = new MemberDetailServiceImpl().findByMemberno(no);
            if (md == null) {
                JOptionPane.showMessageDialog(null, "查無此會員", "提示", JOptionPane.ERROR_MESSAGE);
                return;
            }

            DefaultTableModel model = new DefaultTableModel(new Object[]{"欄位", "資料"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return column == 1 && row != 0 && row != 2 && row != 7;
                }
            };
            memberShow.setModel(model);

            model.addRow(new Object[]{"會員編號", md.getMemberno()});
            model.addRow(new Object[]{"姓名", md.getMname()});
            model.addRow(new Object[]{"帳號", md.getUsername()});
            model.addRow(new Object[]{"密碼", ""});
            model.addRow(new Object[]{"電話", md.getPhone()});
            model.addRow(new Object[]{"地址", md.getAddress()});
            model.addRow(new Object[]{"會員等級", md.getVipname()});
            model.addRow(new Object[]{"折扣", md.getVip_discount()});

            JComboBox<String> vipCombo = new JComboBox<>();
            for (VipLevel v : allVipLevels) vipCombo.addItem(v.getVname());

            memberShow.setDefaultEditor(Object.class, new DefaultCellEditor(new JTextField()) {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value,
                                                             boolean isSelected, int row, int column) {
                    if (row == 6) return vipCombo;
                    return super.getTableCellEditorComponent(table, value, isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue() {
                    if (vipCombo.getParent() != null) return vipCombo.getSelectedItem();
                    return super.getCellEditorValue();
                }
            });
            }
        });
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnSearch.setFocusPainted(false);
        btnSearch.setBounds(352, 10, 97, 25);
        panel_1.add(btnSearch);

        JButton btnEdit = new JButton("修改");
        btnEdit.setForeground(Color.WHITE);
        btnEdit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (memberShow.isEditing()) memberShow.getCellEditor().stopCellEditing();

                DefaultTableModel model = (DefaultTableModel) memberShow.getModel();
                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(null, "請先查詢會員", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                String memberno = (String) model.getValueAt(0, 1);
                Member member = new MemberServiceImpl().findByMemberno(memberno);
                if (member == null) {
                    JOptionPane.showMessageDialog(null, "會員不存在", "提示", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String phone = (String) model.getValueAt(4, 1);

                if (!phone.matches("^09\\d{8}$")) {
                    JOptionPane.showMessageDialog(null, "手機格式錯誤，請輸入09開頭的10位手機號碼!", "提示", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                member.setMname((String) model.getValueAt(1, 1));
                String newPwd = (String) model.getValueAt(3, 1);
                if (!newPwd.isEmpty()) member.setPassword(newPwd);
                member.setPhone(phone);
                member.setAddress((String) model.getValueAt(5, 1));

                String vipName = (String) model.getValueAt(6, 1);
                VipLevel vl = allVipLevels.stream().filter(v -> v.getVname().equals(vipName)).findFirst().orElse(null);
                if (vl != null) {
                    member.setViplevelno(vl.getViplevelno());

                    double discount = vl.getDiscount();
                    String discountText;
                    if (discount >= 1.0) {
                        discountText = "無折扣";
                    } else {
                        discountText = (int)(discount * 100) + "折";
                        if (discount * 100 % 10 == 0) {
                            discountText = String.valueOf((int)(discount * 10)) + "折";
                        }
                    }
                    model.setValueAt(discountText, 7, 1);
                }

                boolean updated = new MemberServiceImpl().updateMember(member);
                if (updated) JOptionPane.showMessageDialog(null, "修改完成", "提示", JOptionPane.INFORMATION_MESSAGE);
                else JOptionPane.showMessageDialog(null, "修改失敗", "提示", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnEdit.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnEdit.setFocusPainted(false);
        btnEdit.setBackground(new Color(0, 128, 192));
        btnEdit.setBounds(352, 121, 97, 93);
        panel_1.add(btnEdit);

        JButton btnBack = new JButton("返回首頁");
        btnBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ManagerHome managerhome = new ManagerHome();
                managerhome.setVisible(true);
                dispose();
            }
        });
        btnBack.setForeground(Color.WHITE);
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setBounds(38, 227, 119, 25);
        panel_1.add(btnBack);

        JButton btnExcel = new JButton("Excel匯出全部會員明細");
        btnExcel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		Tools.exportAllMembersToExcel("全部會員明細.xlsx");
                JOptionPane.showMessageDialog(null, "匯出完成：全部會員明細.xlsx", "提示", JOptionPane.INFORMATION_MESSAGE);
        	}
        });
        btnExcel.setForeground(Color.WHITE);
        btnExcel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnExcel.setFocusPainted(false);
        btnExcel.setBackground(new Color(255, 128, 64));
        btnExcel.setBounds(168, 227, 281, 25);
        panel_1.add(btnExcel);
        
        JButton btnDel = new JButton("<html>刪除<br>此會員</html>");
        btnDel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		 if (memberShow.getRowCount() == 0) {
        		        JOptionPane.showMessageDialog(null, "請先查詢會員", "提示", JOptionPane.WARNING_MESSAGE );
        		        return;
        		    }

        		    int confirm = JOptionPane.showConfirmDialog(null, "確定要刪除此會員嗎?", "刪除確認", JOptionPane.YES_NO_OPTION);
        		    if (confirm != JOptionPane.YES_OPTION) return;

        		    String memberno = (String) memberShow.getValueAt(0, 1);
        		    boolean deleted = new MemberServiceImpl().removeMember(memberno);

        		    if (deleted) {
        		        JOptionPane.showMessageDialog(null, "刪除完成", "提示", JOptionPane.INFORMATION_MESSAGE);
        		        ((DefaultTableModel) memberShow.getModel()).setRowCount(0);
        		    } else {
        		        JOptionPane.showMessageDialog(null, "刪除失敗", "提示", JOptionPane.ERROR_MESSAGE);
        		    }
        	}
        });
        btnDel.setForeground(Color.WHITE);
        btnDel.setFocusPainted(false);
        btnDel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnDel.setFocusPainted(false);
        btnDel.setBackground(new Color(255, 0, 0));
        btnDel.setBounds(352, 51, 97, 60);
        panel_1.add(btnDel);

    }
}
