package controller.employ;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.Login;
import model.Employ;
import model.Product;
import service.impl.ProductServiceImpl;
import util.ManagerThing;
import util.Tools;

public class ProductManager extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable productEdit;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ProductManager frame = new ProductManager();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ProductManager() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
		setSize(490, 390);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(244, 244, 244));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(244, 244, 244));
        panel.setBounds(10, 10, 471, 100);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("商品管理");
        titleLabel.setForeground(new Color(0, 64, 128));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
        titleLabel.setBounds(10, 33, 451, 57);
        panel.add(titleLabel);

        JLabel logout = new JLabel("登出");
        logout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Login login = new Login();
                if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
                    new File("data/employ.txt").delete();
                    login.setVisible(true);
                    dispose();
                    return;
                }
            }
        });
        logout.setForeground(new Color(0, 0, 255));
        logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        logout.setBounds(429, 10, 32, 19);
        panel.add(logout);

        JLabel welcomeMsg = new JLabel("");
        welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
        welcomeMsg.setForeground(new Color(0, 0, 0));
        welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        welcomeMsg.setBounds(10, 10, 413, 19);
        panel.add(welcomeMsg);

        Employ employ = (Employ) Tools.readFile("data/employ.txt");
        String show = employ.getEname() + " 您好";
        welcomeMsg.setText(show);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(244, 244, 244));
        panel_1.setBounds(10, 111, 471, 271);
        contentPane.add(panel_1);
        panel_1.setLayout(null);

        JButton btnBack = new JButton("返回首頁");
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ManagerHome managerhome = new ManagerHome();
                managerhome.setVisible(true);
                dispose();
            }
        });
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setBounds(10, 220, 112, 35);
        panel_1.add(btnBack);
        Object[] columnNames ={"商品編號", "名稱", "價格", "庫存"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0;
            }
        };
        
        productEdit = new JTable(tableModel);
        productEdit.setFont(new Font("微軟正黑體", Font.BOLD, 14));
        JScrollPane scrollPane = new JScrollPane(productEdit);
        scrollPane.setBounds(10, 10, 450, 200);
        panel_1.add(scrollPane);

        ManagerThing.loadProductData(tableModel);

        JButton btnUpdate = new JButton("修改");
        btnUpdate.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
            	if (productEdit.isEditing()) {
            	    productEdit.getCellEditor().stopCellEditing();
            	}
            	
                ProductServiceImpl productService = new ProductServiceImpl();
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    String productNo = (String) tableModel.getValueAt(i, 0);
                    String name = ((String) tableModel.getValueAt(i, 1)).trim();
                    int price;
                    int quantity;

                    try {
                        price = Integer.parseInt(tableModel.getValueAt(i, 2).toString());
                        quantity = Integer.parseInt(tableModel.getValueAt(i, 3).toString());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(ProductManager.this, 
                            "價格或庫存格式錯誤，請輸入整數！", "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    boolean nameExists = productService.findAllProduct()
                            .stream()
                            .anyMatch(p -> !p.getProductno().equals(productNo) && p.getPname().equalsIgnoreCase(name));

                    if (nameExists) {
                        JOptionPane.showMessageDialog(ProductManager.this, 
                            "商品名稱「" + name + "」已存在，請使用其他名稱！", "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    Product p = productService.findByProductno(productNo);
                    if (p == null) continue; 

                    p.setPname(name); 
                    p.setPrice(price);
                    p.setQuantity(quantity);

                    productService.updateProduct(p);
                }

                ManagerThing.loadProductData(tableModel);
                JOptionPane.showMessageDialog(ProductManager.this, "商品修改完成！", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        btnUpdate.setBackground(new Color(0, 128, 192));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnUpdate.setBounds(132, 220, 82, 35);
        panel_1.add(btnUpdate);
        
        JButton btnAddPD = new JButton("新增商品");
        btnAddPD.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JTextField nameField = new JTextField();
                JTextField priceField = new JTextField();
                JTextField quantityField = new JTextField();

                Object[] message = {
                    "名稱:", nameField,
                    "價格:", priceField,
                    "庫存:", quantityField
                };

                int option = JOptionPane.showConfirmDialog(
                        ProductManager.this, message, "新增商品", JOptionPane.OK_CANCEL_OPTION);

                if (option == JOptionPane.OK_OPTION) {
                    String name = nameField.getText().trim();
                    String priceText = priceField.getText().trim();
                    String quantityText = quantityField.getText().trim();

                    if (name.isEmpty() || priceText.isEmpty() || quantityText.isEmpty()) {
                        JOptionPane.showMessageDialog(ProductManager.this, "所有欄位不可為空！", "提示", JOptionPane.WARNING_MESSAGE );
                        return;
                    }

                    boolean nameExists = new ProductServiceImpl().findAllProduct()
                            .stream()
                            .anyMatch(p -> p.getPname().equalsIgnoreCase(name));

                    if (nameExists) {
                        JOptionPane.showMessageDialog(ProductManager.this, "商品名稱已存在，請輸入其他名稱！", "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int price, quantity;
                    try {
                        price = Integer.parseInt(priceText);
                        quantity = Integer.parseInt(quantityText);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(ProductManager.this, "價格或庫存格式錯誤，請輸入整數！", "提示", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int maxCode = new ProductServiceImpl().findAllProduct()
                                        .stream()
                                        .mapToInt(p -> Integer.parseInt(p.getProductno().substring(2)))
                                        .max()
                                        .orElse(0);
                    String productNo = String.format("PD%04d", maxCode + 1);

                    Product p = new Product();
                    p.setProductno(productNo);
                    p.setPname(name);
                    p.setPrice(price);
                    p.setQuantity(quantity);

                    new ProductServiceImpl().addProduct(p);
                    ManagerThing.loadProductData(tableModel);
                    JOptionPane.showMessageDialog(ProductManager.this, "商品新增成功！商品編號：" + productNo, "提示", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        btnAddPD.setForeground(Color.WHITE);
        btnAddPD.setFocusPainted(false);
        btnAddPD.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnAddPD.setBackground(new Color(255, 128, 64));
        btnAddPD.setBounds(348, 220, 113, 35);
        panel_1.add(btnAddPD);
        
        JButton btnDel = new JButton("移除商品");
        btnDel.setForeground(Color.WHITE);
        btnDel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = productEdit.getSelectedRow();
                if (row == -1) {
                    JOptionPane.showMessageDialog(ProductManager.this, "請先選擇要移除的商品！", "提示", JOptionPane.WARNING_MESSAGE );
                    return;
                }

                DefaultTableModel tableModel = (DefaultTableModel) productEdit.getModel();
                String productNo = (String) tableModel.getValueAt(row, 0);
                String productName = (String) tableModel.getValueAt(row, 1);

                int confirm = JOptionPane.showConfirmDialog(
                        ProductManager.this,
                        "確定要移除商品 " + productName + " 嗎？",
                        "移除商品",
                        JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    ProductServiceImpl productService = new ProductServiceImpl();
                    boolean success = productService.removeProduct(productService.findByProductno(productNo));

                    if (success) {
                        ManagerThing.loadProductData(tableModel);
                        JOptionPane.showMessageDialog(ProductManager.this, "商品已移除成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(ProductManager.this, "商品移除失敗！", "提示", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        btnDel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnDel.setFocusPainted(false);
        btnDel.setBackground(new Color(255, 0, 0));
        btnDel.setBounds(224, 220, 113, 35);
        panel_1.add(btnDel);

    }
}
