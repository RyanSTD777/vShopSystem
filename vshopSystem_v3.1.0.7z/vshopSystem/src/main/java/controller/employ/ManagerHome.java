package controller.employ;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Login;
import model.Employ;
import util.Tools;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class ManagerHome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerHome frame = new ManagerHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerHome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 244, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 471, 100);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel titleLabel = new JLabel("管理系統");
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
		titleLabel.setBounds(10, 33, 451, 57);
		panel.add(titleLabel);
		
		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login,"是否登出系統?","登出提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/employ.txt").delete();
					login.setVisible(true);
					dispose();
					return;
					}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(429, 10, 32, 19);
		panel.add(logout);
		
		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 413, 19);
		panel.add(welcomeMsg);
		
		Employ employ = (Employ)Tools.readFile("data/employ.txt");
		String show=employ.getEname()+" 您好";
		welcomeMsg.setText(show);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 111, 471, 271);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton exitButton = new JButton("離開系統");
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ManagerHome managerhome = new ManagerHome();
				if (JOptionPane.showConfirmDialog(managerhome,"是否離開系統?","關閉提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/employ.txt").delete();
					System.exit(0);
					}
			}
		});
		exitButton.setForeground(Color.WHITE);
		exitButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		exitButton.setFocusPainted(false);
		exitButton.setBackground(new Color(255, 0, 0));
		exitButton.setBounds(152, 206, 134, 46);
		panel_1.add(exitButton);
		
		JButton memberButton = new JButton("會員管理");
		memberButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MemberManager membermanager = new MemberManager();
				membermanager.setVisible(true);
				dispose();
			}
		});
		memberButton.setForeground(Color.WHITE);
		memberButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		memberButton.setFocusPainted(false);
		memberButton.setBackground(new Color(255, 128, 0));
		memberButton.setBounds(152, 143, 134, 46);
		panel_1.add(memberButton);
		
		JButton porderButton = new JButton("訂單管理");
		porderButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OrderManager ordermanager = new OrderManager();
				ordermanager.setVisible(true);
				dispose();
			}
		});
		porderButton.setForeground(Color.WHITE);
		porderButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		porderButton.setFocusPainted(false);
		porderButton.setBackground(new Color(0, 128, 0));
		porderButton.setBounds(152, 80, 134, 46);
		panel_1.add(porderButton);
		
		JButton productButton = new JButton("商品管理");
		productButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ProductManager productmanager = new ProductManager();
				productmanager.setVisible(true);
				dispose();
			}
		});
		productButton.setForeground(Color.WHITE);
		productButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		productButton.setFocusPainted(false);
		productButton.setBackground(new Color(0, 128, 192));
		productButton.setBounds(152, 17, 134, 46);
		panel_1.add(productButton);

	}
}
