package controller.member;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import controller.Login;
import controller.porder.PorderHome;
import model.Member;
import model.VipLevel;
import service.impl.MemberServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.Tools;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class MyAccManager extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField phone;
	private JTextField address;
	private JPasswordField password;
	private JPasswordField repassword;
	private JLabel passwordVerify;
	private JLabel phoneVerify;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyAccManager frame = new MyAccManager();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MyAccManager() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 471, 100);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel titleLabel = new JLabel("修改個人資料");
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
		titleLabel.setBounds(10, 33, 451, 57);
		panel.add(titleLabel);
		
		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login,"是否登出系統?","登出提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
					return;
					}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(429, 10, 32, 19);
		panel.add(logout);
		
		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 413, 19);
		panel.add(welcomeMsg);
		
		Member member = (Member)Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show="<"+vsi.getVname()+"> "+member.getMname()+" 您好";
		welcomeMsg.setText(show);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 111, 471, 269);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		


        JButton btnBack = new JButton("返回首頁");
        btnBack.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		PorderHome porderhome = new PorderHome();
        		porderhome.setVisible(true);
        		dispose();
        	}
        });
        btnBack.setForeground(Color.WHITE);
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setBounds(32, 222, 119, 30);
        panel_1.add(btnBack);
        
        JButton btnMyAcc = new JButton("返回我的帳號");
        btnMyAcc.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		MyAcc myacc = new MyAcc();
				myacc.setVisible(true);
				dispose();
        	}
        });
        btnMyAcc.setForeground(Color.WHITE);
        btnMyAcc.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnMyAcc.setFocusPainted(false);
        btnMyAcc.setBackground(new Color(255, 128, 64));
        btnMyAcc.setBounds(292, 222, 150, 30);
        panel_1.add(btnMyAcc);
        
        JLabel lblname = new JLabel("姓名:");
        lblname.setHorizontalAlignment(SwingConstants.RIGHT);
        lblname.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblname.setBounds(32, 10, 82, 30);
        panel_1.add(lblname);
        
        JLabel lblpw = new JLabel("密碼:");
        lblpw.setHorizontalAlignment(SwingConstants.RIGHT);
        lblpw.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblpw.setBounds(32, 43, 82, 30);
        panel_1.add(lblpw);
        
        JLabel lblpwck = new JLabel("確認密碼:");
        lblpwck.setHorizontalAlignment(SwingConstants.RIGHT);
        lblpwck.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblpwck.setBounds(32, 76, 82, 30);
        panel_1.add(lblpwck);
        
        JLabel lblphone = new JLabel("電話:");
        lblphone.setHorizontalAlignment(SwingConstants.RIGHT);
        lblphone.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblphone.setBounds(32, 110, 82, 30);
        panel_1.add(lblphone);
        
        JLabel lbladdress = new JLabel("地址:");
        lbladdress.setHorizontalAlignment(SwingConstants.RIGHT);
        lbladdress.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lbladdress.setBounds(32, 143, 82, 30);
        panel_1.add(lbladdress);
        
        name = new JTextField();
        name.setBounds(124, 10, 124, 31);
        panel_1.add(name);
        name.setColumns(10);
        
        phone = new JTextField();
        phone.setColumns(10);
        phone.setBounds(124, 109, 158, 31);
        panel_1.add(phone);

		phone.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                validatePhone();
            }
            public void removeUpdate(DocumentEvent e) {
                validatePhone();
            }
            public void changedUpdate(DocumentEvent e) {
                validatePhone();
            }
        });
        
        address = new JTextField();
        address.setColumns(10);
        address.setBounds(124, 142, 318, 31);
        panel_1.add(address);
        
        password = new JPasswordField();
        password.setBounds(124, 43, 158, 30);
		ImageIcon o_showpw = new ImageIcon(
				MyAccManager.class.getResource("/button/showpw.png")
			);
		Image sc_showpw = o_showpw.getImage().getScaledInstance(35, 24, Image.SCALE_SMOOTH);
		ImageIcon re_showpw = new ImageIcon(sc_showpw);
        JButton showButton = new JButton(re_showpw);
        showButton.setBackground(new Color(244, 244, 244));
        showButton.setBounds(292, 43, 34, 29);
        showButton.setBorderPainted(false);
        showButton.setFocusPainted(false);
        showButton.setContentAreaFilled(false);
        char defaultEchoChar = password.getEchoChar();
        showButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                password.setEchoChar((char) 0);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                password.setEchoChar(defaultEchoChar);
            }
        });
        panel_1.add(showButton);
		panel_1.add(password);
        
        repassword = new JPasswordField();
        repassword.setBounds(124, 76, 158, 30);
        panel_1.add(repassword);		

		repassword.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                validatePassword();
            }
            public void removeUpdate(DocumentEvent e) {
                validatePassword();
            }
            public void changedUpdate(DocumentEvent e) {
                validatePassword();
            }
        });
		
		JButton showButton_re = new JButton(re_showpw);
		showButton_re.setFocusPainted(false);
		showButton_re.setContentAreaFilled(false);
		showButton_re.setBorderPainted(false);
		showButton_re.setBackground(new Color(244, 244, 244));
		showButton_re.setBounds(292, 76, 34, 29);
        char defaultEchoChar_re = repassword.getEchoChar();
        showButton_re.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                repassword.setEchoChar((char) 0);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                repassword.setEchoChar(defaultEchoChar_re);
            }
        });
		panel_1.add(showButton_re);
		
		passwordVerify = new JLabel("密碼不相符");
		passwordVerify.setForeground(new Color(255, 0, 0));
		passwordVerify.setVisible(false);
		passwordVerify.setHorizontalAlignment(SwingConstants.LEFT);
		passwordVerify.setFont(new Font("微軟正黑體", Font.BOLD, 17));
		passwordVerify.setBounds(336, 37, 110, 42);
		panel_1.add(passwordVerify);
		
		phoneVerify = new JLabel("格式錯誤");
		phoneVerify.setBackground(new Color(240, 240, 240));
		phoneVerify.setForeground(new Color(255, 0, 0));
		phoneVerify.setVisible(false);
		phoneVerify.setOpaque(true);
		phoneVerify.setHorizontalAlignment(SwingConstants.LEFT);
		phoneVerify.setFont(new Font("微軟正黑體", Font.BOLD, 17));
		phoneVerify.setBounds(292, 110, 169, 30);
		panel_1.add(phoneVerify);
		
		JLabel lblNewphoneVerify_1_1_1_1_2 = new JLabel("(格式:09XXXXXXXX)");
		lblNewphoneVerify_1_1_1_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewphoneVerify_1_1_1_1_2.setFont(new Font("微軟正黑體", Font.BOLD, 17));
		lblNewphoneVerify_1_1_1_1_2.setBounds(292, 110, 179, 30);
		panel_1.add(lblNewphoneVerify_1_1_1_1_2);
        
        JButton btnEdit = new JButton("修改");
        btnEdit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String pwd1 = String.valueOf(password.getPassword());
                String pwd2 = String.valueOf(repassword.getPassword());
                if (!pwd1.equals(pwd2)) {
                    JOptionPane.showMessageDialog(MyAccManager.this, "密碼不相符，請重新輸入！", "提示", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String phoneText = phone.getText().trim();
                if (!phoneText.isEmpty() && !phoneText.matches("09\\d{8}")) {
                    JOptionPane.showMessageDialog(MyAccManager.this, "手機格式錯誤，請輸入09開頭的10位手機號碼!", "提示", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                if (!name.getText().isEmpty()) {
                    member.setMname(name.getText());
                }
                if (!phoneText.isEmpty()) {
                    member.setPhone(phoneText);
                }
                if (!address.getText().isEmpty()) {
                    member.setAddress(address.getText());
                }
                if (!pwd1.isEmpty()) {
                    member.setPassword(pwd1);
                }
                boolean success = new MemberServiceImpl().updateMember(member);
                if (success) {
                    JOptionPane.showMessageDialog(MyAccManager.this, "會員資料修改成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(MyAccManager.this, "資料有誤，修改失敗！", "提示", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnEdit.setBackground(new Color(0, 128, 192));
        btnEdit.setForeground(new Color(255, 255, 255));
        btnEdit.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        btnEdit.setBounds(174, 222, 97, 30);
        panel_1.add(btnEdit);
        
        JLabel lblNewLabel = new JLabel("溫馨提示: 只需輸入需修改的項目，在點修改即可~");
        lblNewLabel.setForeground(new Color(128, 0, 255));
        lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        lblNewLabel.setBounds(32, 183, 410, 34);
        panel_1.add(lblNewLabel);

	}
	
	private void validatePassword() {
	    String pwd1 = String.valueOf(password.getPassword());
	    String pwd2 = String.valueOf(repassword.getPassword());

	    if (!pwd1.equals(pwd2)) {
	    	passwordVerify.setVisible(true);
	    } else {
	    	passwordVerify.setVisible(false);
	    }
	}

	private void validatePhone() {
	    String Phone = phone.getText();
	    if (Phone.isEmpty()) {
	        phoneVerify.setVisible(false);
	        return;
	    }
	    boolean isValid = Phone.matches("^09\\d{8}$");

	    phoneVerify.setVisible(!isValid);
	}
}
