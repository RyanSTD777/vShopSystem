package controller.member;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import controller.Login;
import model.Member;
import service.impl.MemberServiceImpl;
import util.GenNumber;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;

public class RegMember extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField username;
	private JTextField name;
	private JTextField phone;
	private JTextField address;
	private JPasswordField password;
	private JPasswordField repassword;
	private JLabel passwordVerify;
	private JLabel phoneVerify;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegMember frame = new RegMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegMember() {
		setBackground(new Color(244, 244, 244));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(591, 450);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBackground(new Color(244, 244, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 563, 59);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("會員註冊");
		lblNewLabel.setBackground(new Color(244, 244, 244));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 563, 59);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(0, 0, 0));
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 69, 563, 279);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("帳號:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1.setBounds(10, 10, 105, 42);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("密碼:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(10, 54, 105, 42);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("姓名:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(10, 142, 105, 42);
		panel_1.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("電話:");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1_1_1.setBounds(10, 186, 105, 42);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("地址:");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1_1_1_1.setBounds(10, 230, 105, 42);
		panel_1.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("確認密碼:");
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_2.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1_2.setBounds(10, 98, 105, 42);
		panel_1.add(lblNewLabel_1_1_2);
		
		username = new JTextField();
		username.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		username.setBounds(125, 11, 211, 42);
		panel_1.add(username);
		username.setColumns(10);
		
		name = new JTextField();
		name.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		name.setColumns(10);
		name.setBounds(125, 142, 146, 42);
		panel_1.add(name);
		
		phone = new JTextField();
		phone.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		phone.setColumns(10);
		phone.setBounds(125, 186, 211, 42);
		panel_1.add(phone);

		phone.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                validatePhone();
            }
            public void removeUpdate(DocumentEvent e) {
                validatePhone();
            }
            public void changedUpdate(DocumentEvent e) {
                validatePhone();
            }
        });
		
		address = new JTextField();
		address.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		address.setColumns(10);
		address.setBounds(125, 230, 367, 42);
		panel_1.add(address);
		
		password = new JPasswordField(15);
		password.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		password.setBounds(125, 54, 211, 42);
		ImageIcon o_showpw = new ImageIcon(
				RegMember.class.getResource("/button/showpw.png")
			);
		Image sc_showpw = o_showpw.getImage().getScaledInstance(35, 24, Image.SCALE_SMOOTH);
		ImageIcon re_showpw = new ImageIcon(sc_showpw);
        JButton showButton = new JButton(re_showpw);
        showButton.setBackground(new Color(244, 244, 244));
        showButton.setBounds(346, 62, 34, 29);
        showButton.setBorderPainted(false);
        showButton.setFocusPainted(false);
        showButton.setContentAreaFilled(false);
        char defaultEchoChar = password.getEchoChar();
        showButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                password.setEchoChar((char) 0);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                password.setEchoChar(defaultEchoChar);
            }
        });
        panel_1.add(showButton);
		panel_1.add(password);
		
		repassword = new JPasswordField();
		repassword.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		repassword.setBounds(125, 98, 211, 42);
		panel_1.add(repassword);
		

		repassword.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                validatePassword();
            }
            public void removeUpdate(DocumentEvent e) {
                validatePassword();
            }
            public void changedUpdate(DocumentEvent e) {
                validatePassword();
            }
        });
		
		/**按鈕**/
		JButton showButton_re = new JButton(re_showpw);
		showButton_re.setFocusPainted(false);
		showButton_re.setContentAreaFilled(false);
		showButton_re.setBorderPainted(false);
		showButton_re.setBackground(new Color(244, 244, 244));
		showButton_re.setBounds(346, 107, 34, 29);
        char defaultEchoChar_re = repassword.getEchoChar();
        showButton_re.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                repassword.setEchoChar((char) 0);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                repassword.setEchoChar(defaultEchoChar_re);
            }
        });
		panel_1.add(showButton_re);
		
		passwordVerify = new JLabel("密碼不相符");
		passwordVerify.setForeground(new Color(255, 0, 0));
		passwordVerify.setVisible(false);
		passwordVerify.setHorizontalAlignment(SwingConstants.LEFT);
		passwordVerify.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		passwordVerify.setBounds(388, 54, 165, 42);
		panel_1.add(passwordVerify);
		
		phoneVerify = new JLabel("格式錯誤");
		phoneVerify.setBackground(new Color(240, 240, 240));
		phoneVerify.setForeground(new Color(255, 0, 0));
		phoneVerify.setVisible(false);
		phoneVerify.setOpaque(true);
		phoneVerify.setHorizontalAlignment(SwingConstants.LEFT);
		phoneVerify.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		phoneVerify.setBounds(346, 186, 207, 42);
		panel_1.add(phoneVerify);
		
		JLabel lblNewphoneVerify_1_1_1_1_2 = new JLabel("(格式:09XXXXXXXX)");
		lblNewphoneVerify_1_1_1_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewphoneVerify_1_1_1_1_2.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewphoneVerify_1_1_1_1_2.setBounds(346, 186, 207, 42);
		panel_1.add(lblNewphoneVerify_1_1_1_1_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(0, 0, 0));
		panel_2.setBackground(new Color(244, 244, 244));
		panel_2.setBounds(10, 347, 563, 57);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JButton clsButton = new JButton("清空");
		clsButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				username.setText("");
				password.setText("");
				repassword.setText("");
				name.setText("");
				phone.setText("");
				address.setText("");
			}
		});
		clsButton.setForeground(new Color(255, 255, 255));
		clsButton.setBackground(new Color(255, 0, 0));
		clsButton.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		clsButton.setBounds(232, 10, 98, 37);
		clsButton.setFocusPainted(false);
		panel_2.add(clsButton);
		
		JButton okButton = new JButton("送出");
		okButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Memberno = GenNumber.generateMemberNo();
				String Username = username.getText().trim();
				String Password = password.getText().trim();
				String Repassword = repassword.getText().trim();
				String Name = name.getText().trim();
				String Phone = phone.getText();
				String Address = address.getText().trim();
				String Viplevelno = "VIP000";
				if(Username.isEmpty() || Password.isEmpty() || Repassword.isEmpty() || Name.isEmpty() 
						|| Phone.isEmpty() || Address.isEmpty()) {
					JOptionPane.showMessageDialog(null,"部分資料為空，未填寫完整！", "提示", JOptionPane.WARNING_MESSAGE);
			        return;
				}else if(!Password.equals(Repassword) && !Phone.matches("^09\\d{8}$")){
					 JOptionPane.showMessageDialog(null, "輸入密碼不相符、手機格式錯誤，請重新輸入！", "提示", JOptionPane.ERROR_MESSAGE);
					 password.setText("");
					 repassword.setText("");
					 phone.setText("");
				}else if(!Password.equals(Repassword)){
					 JOptionPane.showMessageDialog(null, "輸入密碼不相符，請重新輸入！", "提示", JOptionPane.ERROR_MESSAGE);
					 password.setText("");
					 repassword.setText("");
				}else if (!Phone.matches("^09\\d{8}$")) {
				    JOptionPane.showMessageDialog(null, "手機格式錯誤，請輸入09開頭的10位手機號碼!", "提示", JOptionPane.ERROR_MESSAGE);
				    phone.setText("");
				    return;
				}else {
					Member member = new Member(Memberno,Name,Username,Password,Phone,Address,Viplevelno);
					if(new MemberServiceImpl().regMember(member)) {
						JOptionPane.showMessageDialog(null,"註冊成功", "提示", JOptionPane.INFORMATION_MESSAGE);
						Login login = new Login();
						login.setVisible(true);
						dispose();
					}else {
						JOptionPane.showMessageDialog(null, "帳號重複，請更換其他帳號！", "提示", JOptionPane.ERROR_MESSAGE);
						username.setText("");
					}
				}
			}
		});
		okButton.setForeground(new Color(255, 255, 255));
		okButton.setBackground(new Color(0, 128, 192));
		okButton.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		okButton.setBounds(397, 10, 98, 37);
		okButton.setFocusPainted(false);
		panel_2.add(okButton);
		
		JButton backButton = new JButton("返回");
		backButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		backButton.setForeground(new Color(255, 255, 255));
		backButton.setBackground(new Color(0, 128, 0));
		backButton.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		backButton.setBounds(67, 10, 98, 37);
		backButton.setFocusPainted(false);
		panel_2.add(backButton);

	}
	
	private void validatePassword() {
	    String pwd1 = String.valueOf(password.getPassword());
	    String pwd2 = String.valueOf(repassword.getPassword());

	    if (!pwd1.equals(pwd2)) {
	    	passwordVerify.setVisible(true);
	    } else {
	    	passwordVerify.setVisible(false);
	    }
	}

	private void validatePhone() {
	    String Phone = phone.getText();
	    if (Phone.isEmpty()) {
	        phoneVerify.setVisible(false);
	        return;
	    }
	    boolean isValid = Phone.matches("^09\\d{8}$");

	    phoneVerify.setVisible(!isValid);
	}
}
