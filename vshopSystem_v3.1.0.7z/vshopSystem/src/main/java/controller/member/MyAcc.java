package controller.member;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import controller.Login;
import controller.porder.PorderHome;
import model.Member;
import model.VipLevel;
import service.impl.VipLevelServiceImpl;
import util.Tools;
import javax.swing.JTextArea;

public class MyAcc extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyAcc frame = new MyAcc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MyAcc() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 471, 100);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel titleLabel = new JLabel("我的帳號");
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
		titleLabel.setBounds(10, 33, 451, 57);
		panel.add(titleLabel);
		
		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login,"是否登出系統?","登出提示",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
					return;
					}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(429, 10, 32, 19);
		panel.add(logout);
		
		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 413, 19);
		panel.add(welcomeMsg);
		
		Member member = (Member)Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show="<"+vsi.getVname()+"> "+member.getMname()+" 您好";
		welcomeMsg.setText(show);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 111, 471, 269);
		contentPane.add(panel_1);
		panel_1.setLayout(null);	
        
		JTextArea accShow = new JTextArea();
		accShow.setBackground(new Color(244, 244, 244));
		accShow.setFont(new Font("微軟正黑體", Font.BOLD, 16));
		accShow.setBounds(20, 10, 428, 207);
		accShow.setEditable(false);
		panel_1.add(accShow);

		StringBuilder sb = new StringBuilder();
		sb.append("會員編號: ").append(member.getMemberno()).append("\n");
		sb.append("姓名: ").append(member.getMname()).append("\n");
		sb.append("帳號: ").append(member.getUsername()).append("\n");
		sb.append("手機: ").append(member.getPhone()).append("\n");
		sb.append("地址: ").append(member.getAddress()).append("\n");
		sb.append("VIP等級: ").append(vsi.getVname()).append("\n");

		accShow.setText(sb.toString());

        JButton btnBack = new JButton("返回首頁");
        btnBack.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		PorderHome porderhome = new PorderHome();
        		porderhome.setVisible(true);
        		dispose();
        	}
        });
        btnBack.setForeground(Color.WHITE);
        btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(0, 128, 0));
        btnBack.setBounds(70, 227, 119, 25);
        panel_1.add(btnBack);
        
        JButton btnEdit = new JButton("修改個人資料");
        btnEdit.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		MyAccManager myaccmanager = new MyAccManager();
        		myaccmanager.setVisible(true);
        		dispose();
        	}
        });
        btnEdit.setForeground(Color.WHITE);
        btnEdit.setFont(new Font("微軟正黑體", Font.BOLD, 18));
        btnEdit.setFocusPainted(false);
        btnEdit.setBackground(new Color(0, 128, 192));
        btnEdit.setBounds(235, 227, 164, 25);
        panel_1.add(btnEdit);

	}
}
