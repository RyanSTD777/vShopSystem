package controller.member;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.Login;
import controller.porder.PorderHome;
import model.Member;
import model.Porder;
import model.VipLevel;
import service.impl.PorderServiceImpl;
import service.impl.VipLevelServiceImpl;
import util.ProductThing;
import util.Tools;

public class MyOrderManager extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				MyOrderManager frame = new MyOrderManager();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public MyOrderManager() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setSize(490, 390);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 471, 100);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel titleLabel = new JLabel("訂單管理");
		titleLabel.setForeground(new Color(0, 64, 128));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("微軟正黑體", Font.BOLD, 46));
		titleLabel.setBounds(10, 33, 451, 57);
		panel.add(titleLabel);

		JLabel logout = new JLabel("登出");
		logout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				if (JOptionPane.showConfirmDialog(login, "是否登出系統?", "登出提示",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					new File("data/member.txt").delete();
					new File("data/porder.txt").delete();
					login.setVisible(true);
					dispose();
				}
			}
		});
		logout.setForeground(new Color(0, 0, 255));
		logout.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		logout.setBounds(429, 10, 32, 19);
		panel.add(logout);

		JLabel welcomeMsg = new JLabel("");
		welcomeMsg.setHorizontalAlignment(SwingConstants.RIGHT);
		welcomeMsg.setForeground(new Color(0, 0, 0));
		welcomeMsg.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		welcomeMsg.setBounds(10, 10, 413, 19);
		panel.add(welcomeMsg);

		Member member = (Member) Tools.readFile("data/member.txt");
		VipLevel vsi = new VipLevelServiceImpl().findByVipLevelno(member.getViplevelno());
		String show = "<" + vsi.getVname() + "> " + member.getMname() + " 您好";
		welcomeMsg.setText(show);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 111, 471, 269);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JButton btnBack = new JButton("返回首頁");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PorderHome porderhome = new PorderHome();
				porderhome.setVisible(true);
				dispose();
			}
		});

		JLabel lblNewLabel_1 = new JLabel("溫馨提示:  只能修改商品數量!");
		lblNewLabel_1.setForeground(new Color(128, 0, 128));
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 17));
		lblNewLabel_1.setBounds(28, 188, 410, 29);
		panel_1.add(lblNewLabel_1);
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		btnBack.setFocusPainted(false);
		btnBack.setBackground(new Color(0, 128, 0));
		btnBack.setBounds(64, 227, 119, 25);
		panel_1.add(btnBack);

		JButton btnMyOrder = new JButton("我的訂單");
		btnMyOrder.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MyOrder myorder = new MyOrder();
				myorder.setVisible(true);
				dispose();
			}
		});
		btnMyOrder.setForeground(Color.WHITE);
		btnMyOrder.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		btnMyOrder.setFocusPainted(false);
		btnMyOrder.setBackground(new Color(255, 128, 64));
		btnMyOrder.setBounds(285, 227, 119, 25);
		panel_1.add(btnMyOrder);

		JLabel lblNewLabel = new JLabel("訂單編號:");
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel.setBounds(28, 10, 95, 28);
		panel_1.add(lblNewLabel);

		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBounds(118, 10, 151, 28);
		panel_1.add(comboBox);

		DefaultTableModel tableModel = new DefaultTableModel(new Object[] { "商品編號", "商品名稱", "數量", "單價", "小計" }, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 2;
			}
		};

		table = new JTable(tableModel);
		table.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(28, 48, 410, 133);
		panel_1.add(scrollPane);

		ProductThing.loadOrderNumbers(member.getMemberno(), comboBox);

		comboBox.addActionListener(e -> {
		    String orderNo = (String) comboBox.getSelectedItem();
		    if (orderNo != null && !"請選擇訂單".equals(orderNo)) {
		        ProductThing.loadOrderDetails(orderNo, tableModel);
		    } else {
		        tableModel.setRowCount(0);
		    }
		});

		JButton btnUpdate = new JButton("修改");
		btnUpdate.setBackground(new Color(0, 128, 192));
		btnUpdate.addActionListener(e -> {
			if (table.isEditing()) 
			    table.getCellEditor().stopCellEditing();
			String selected = (String) comboBox.getSelectedItem();
			if ("====請選擇訂單====".equals(selected)) {
				JOptionPane.showMessageDialog(this, "請先選擇一筆訂單！", "提示", JOptionPane.WARNING_MESSAGE );
			} else {
				ProductThing.updateOrder(comboBox, tableModel);
			}
		});
		btnUpdate.setForeground(Color.WHITE);
		btnUpdate.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		btnUpdate.setBounds(279, 11, 80, 27);
		panel_1.add(btnUpdate);


		JButton btnDel = new JButton("刪除");
		btnDel.setBackground(new Color(255, 0, 0));
		btnDel.addActionListener(e -> {
			String orderNo = (String) comboBox.getSelectedItem();
			if (orderNo == null || "請選擇訂單".equals(orderNo)) {
				JOptionPane.showMessageDialog(this, "請先選擇一筆訂單！", "提示", JOptionPane.WARNING_MESSAGE );
				return;
			}

			int confirm = JOptionPane.showConfirmDialog(this, "確定要刪除此訂單嗎？", "刪除確認", JOptionPane.YES_NO_OPTION);
			if (confirm == JOptionPane.YES_OPTION) {
				PorderServiceImpl psi = new PorderServiceImpl();
				Porder porder = new Porder();
				porder.setPorderno(orderNo);

				boolean result = psi.removePorder(porder);
				if (result) {
					JOptionPane.showMessageDialog(this, "訂單 " + orderNo + " 已刪除！", "提示", JOptionPane.INFORMATION_MESSAGE);
					ProductThing.loadOrderNumbers(member.getMemberno(), comboBox);
					tableModel.setRowCount(0);
				} else {
					JOptionPane.showMessageDialog(this, "訂單不存在！", "提示", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnDel.setForeground(new Color(255, 255, 255));
		btnDel.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		btnDel.setBounds(363, 11, 80, 27);
		panel_1.add(btnDel);		

	}
}