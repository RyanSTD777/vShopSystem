package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.employ.ManagerHome;
import controller.member.RegMember;
import controller.porder.PorderHome;
import service.impl.EmployServiceImpl;
import service.impl.MemberServiceImpl;
import util.Tools;
import model.Employ;
import model.Member;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(420, 302);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 244, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(244, 244, 244));
		panel.setBounds(10, 10, 385, 65);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("系統登入");
		lblNewLabel.setForeground(new Color(0, 64, 128));
		lblNewLabel.setFont(new Font("微軟正黑體", Font.BOLD, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 10, 365, 45);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(244, 244, 244));
		panel_1.setBounds(10, 75, 385, 103);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("帳號:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1.setBounds(10, 10, 78, 43);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("密碼:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(10, 54, 78, 43);
		panel_1.add(lblNewLabel_1_1);
		
		username = new JTextField();
		username.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		username.setBounds(98, 10, 215, 43);
		panel_1.add(username);
		username.setColumns(10);
		
		password = new JPasswordField();
		password.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		password.setBounds(98, 54, 215, 40);
		ImageIcon o_showpw = new ImageIcon(
				Login.class.getResource("/button/showpw.png")
			);
		Image sc_showpw = o_showpw.getImage().getScaledInstance(35, 24, Image.SCALE_SMOOTH);
		ImageIcon re_showpw = new ImageIcon(sc_showpw);
        JButton showButton = new JButton(re_showpw);
        showButton.setBackground(new Color(244, 244, 244));
        showButton.setBounds(323, 60, 34, 29);
        showButton.setBorderPainted(false);
        showButton.setFocusPainted(false);
        showButton.setContentAreaFilled(false);
        char defaultEchoChar = password.getEchoChar();
        showButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                password.setEchoChar((char) 0);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                password.setEchoChar(defaultEchoChar);
            }
        });
        panel_1.add(showButton);
		panel_1.add(password);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(244, 244, 244));
		panel_2.setBounds(10, 178, 385, 87);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblVer = new JLabel("v3.1.0");
		lblVer.setHorizontalAlignment(SwingConstants.RIGHT);
		lblVer.setFont(new Font("微軟正黑體", Font.BOLD, 18));
		lblVer.setBounds(10, 44, 365, 33);
		panel_2.add(lblVer);
		
		JButton loginButton = new JButton("登入");
		loginButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Username = username.getText();
				String Password = password.getText();
				
				Member msi = new MemberServiceImpl().login(Username, Password);
				Employ esi = new EmployServiceImpl().login(Username, Password);
				boolean checkmember = new MemberServiceImpl().existsByUsername(Username);
				boolean checkemploy = new EmployServiceImpl().existsByUsername(Username);
				
				if(msi!=null||esi!=null)
				{
					if(msi!=null) {
						new File("data").mkdirs();
						Tools.saveFile(msi, "data/member.txt");
						PorderHome porderhome = new PorderHome();
						porderhome.setVisible(true);
						dispose();
					}else{
						new File("data").mkdirs();
						Tools.saveFile(esi, "data/employ.txt");
						ManagerHome managerhome = new ManagerHome();
						managerhome.setVisible(true);
						dispose();
					}					
				}else if(Username.isEmpty() || Password.isEmpty()){
					JOptionPane.showMessageDialog(null,"帳號或密碼為空！", "提示", JOptionPane.ERROR_MESSAGE);
			        return;
				}else if(checkmember == false && checkemploy == false){
					JOptionPane.showMessageDialog(null,"查無此帳號！", "提示", JOptionPane.ERROR_MESSAGE);
			        return;
				}else {
					JOptionPane.showMessageDialog(null,"帳號或密碼有誤，請重新輸入。", "提示", JOptionPane.ERROR_MESSAGE);
			        return;
				}
			}
		});
		loginButton.setForeground(new Color(255, 255, 255));
		loginButton.setBackground(new Color(0, 128, 192));
		loginButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		loginButton.setBounds(96, 0, 85, 45);
		loginButton.setFocusPainted(false);
		panel_2.add(loginButton);
		
		JButton regButton = new JButton("註冊");
		regButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RegMember regmember = new RegMember();
				regmember.setVisible(true);
				dispose();
			}
		});
		regButton.setForeground(new Color(255, 255, 255));
		regButton.setBackground(new Color(0, 128, 0));
		regButton.setFont(new Font("微軟正黑體", Font.BOLD, 20));
		regButton.setBounds(228, 0, 85, 45);
		regButton.setFocusPainted(false);
		panel_2.add(regButton);

	}
}
